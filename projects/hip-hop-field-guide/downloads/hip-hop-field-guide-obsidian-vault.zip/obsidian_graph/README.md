# Using this vault

1. Unzip the folder.
2. In Obsidian choose **Open folder as vault** and select this folder.
3. Open **_Start Here**.
4. Choose **Open graph view** from the command palette or the ribbon.

The graph has 64 notes. Gray context nodes are important routes beyond the 220-position edition. The graph is navigational, not canonical.
