---
title: "Busta Rhymes & Big Pun"
map-group: context
node-id: context-busta-pun
tags:
  - hip-hop-field-guide
  - map/context
---

# Busta Rhymes & Big Pun

Two major 1990s virtuoso-performance routes whose omission remains a legitimate objection.

## Direct connections

- [[Regional systems]]
- [[Expansion & counterpublics]]

## Guide examples

- [Read the omission challenge](https://wdlinch3.github.io/projects/hip-hop-field-guide/manifest_audit.html#omission-and-redundancy-challenge)

[[_Start Here|Return to atlas index]]
