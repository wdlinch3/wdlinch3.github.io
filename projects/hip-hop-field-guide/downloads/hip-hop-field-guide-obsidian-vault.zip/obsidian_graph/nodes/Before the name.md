---
title: "Before the name"
map-group: era
node-id: HH01
tags:
  - hip-hop-field-guide
  - map/era
---

# Before the name

Historical route block with 12 guide positions.

## Direct connections

- [[New York borough systems]]
- [[Los Angeles & Compton]]
- [[United Kingdom]]
- [[DJ, breaks & turntablism]]
- [[Sampling & boom bap]]
- [[Abstract, industrial & experimental]]
- [[Party, dance & crowd command]]
- [[Message & political rap]]
- [[Storytelling & reportage]]
- [[Gangsta & street rap]]

## Guide examples

- [Pigmeat Markham — Here Comes the Judge](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/01-before-the-name.html#track-001)
- [King Stitt — Fire Corner](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/01-before-the-name.html#track-002)
- [The Last Poets — When the Revolution Comes](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/01-before-the-name.html#track-003)
- [U-Roy — Wake the Town](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/01-before-the-name.html#track-004)
- [James Brown — Funky Drummer](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/01-before-the-name.html#track-005)

[[_Start Here|Return to atlas index]]
