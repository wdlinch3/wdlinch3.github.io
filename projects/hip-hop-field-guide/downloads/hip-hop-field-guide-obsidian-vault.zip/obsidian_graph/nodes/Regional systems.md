---
title: "Regional systems"
map-group: era
node-id: HH06
tags:
  - hip-hop-field-guide
  - map/era
---

# Regional systems

Historical route block with 26 guide positions.

## Direct connections

- [[New York borough systems]]
- [[Philadelphia & New Jersey]]
- [[Los Angeles & Compton]]
- [[Bay Area]]
- [[Atlanta]]
- [[Houston]]
- [[Memphis]]
- [[New Orleans]]
- [[Midwest systems]]
- [[France & francophone circuits]]
- [[Latin American & Caribbean circuits]]
- [[African scenes]]
- [[DJ, breaks & turntablism]]
- [[Sampling & boom bap]]
- [[G-funk]]
- [[Bass, bounce & dance systems]]
- [[Chopped and screwed]]
- [[Melody & vocal processing]]
- [[Abstract, industrial & experimental]]
- [[Party, dance & crowd command]]
- [[Message & political rap]]
- [[Storytelling & reportage]]
- [[Flow & lyrical formalism]]
- [[Gangsta & street rap]]
- [[Interiority, testimony & mourning]]
- [[Independent labels & regional business]]
- [[Mixtapes & street media]]
- [[Freestyle Fellowship & Pharcyde routes]]
- [[Fugees as a group]]
- [[Busta Rhymes & Big Pun]]
- [[Scarface solo route]]
- [[Dance, graffiti, radio & organizing beyond tracks]]

## Guide examples

- [Dr. Dre featuring Snoop Doggy Dogg — Nuthin' but a 'G' Thang](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/06-regional-systems.html#track-081)
- [Snoop Doggy Dogg — Gin and Juice](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/06-regional-systems.html#track-082)
- [2Pac — Keep Ya Head Up](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/06-regional-systems.html#track-083)
- [Wu-Tang Clan — C.R.E.A.M.](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/06-regional-systems.html#track-084)
- [Nas — N.Y. State of Mind](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/06-regional-systems.html#track-085)

[[_Start Here|Return to atlas index]]
