---
title: "Dälek, clipping. & noise-rap branches"
map-group: context
node-id: context-noise
tags:
  - hip-hop-field-guide
  - map/context
---

# Dälek, clipping. & noise-rap branches

Industrial, noise, and formally disruptive lineages beyond the selected experimental exhibits.

## Direct connections

- [[South, mixtapes & producers]]
- [[Fractured center]]
- [[Platform era]]

## Guide examples

- [Read the omission challenge](https://wdlinch3.github.io/projects/hip-hop-field-guide/manifest_audit.html#omission-and-redundancy-challenge)

[[_Start Here|Return to atlas index]]
