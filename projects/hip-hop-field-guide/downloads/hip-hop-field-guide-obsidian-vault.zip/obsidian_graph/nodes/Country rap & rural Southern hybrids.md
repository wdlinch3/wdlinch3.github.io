---
title: "Country rap & rural Southern hybrids"
map-group: context
node-id: context-country
tags:
  - hip-hop-field-guide
  - map/context
---

# Country rap & rural Southern hybrids

A durable boundary route involving regional identity, guitar and sample repertoires, independent scenes, and crossover markets.

## Direct connections

- [[South, mixtapes & producers]]
- [[Internet transition]]
- [[Fractured center]]
- [[Platform era]]
- [[Unfinished present]]

## Guide examples

- [Read the omission challenge](https://wdlinch3.github.io/projects/hip-hop-field-guide/manifest_audit.html#omission-and-redundancy-challenge)

[[_Start Here|Return to atlas index]]
