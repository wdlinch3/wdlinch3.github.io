---
title: "Houston"
map-group: scene
node-id: scene-houston
tags:
  - hip-hop-field-guide
  - map/scene
---

# Houston

Chopped-and-screwed listening, independent labels, car culture, and several generations of street rap.

## Direct connections

- [[Plural golden ages]]
- [[Regional systems]]
- [[Platform era]]

## Guide examples

- [Geto Boys — Mind Playing Tricks on Me](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/05-plural-golden-ages.html#track-068)
- [UGK — One Day](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/06-regional-systems.html#track-093)
- [DJ Screw and Screwed Up Click — June 27th Freestyle](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/06-regional-systems.html#track-095)
- [Travis Scott featuring Kendrick Lamar — goosebumps](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/11-platform-era.html#track-192)

[[_Start Here|Return to atlas index]]
