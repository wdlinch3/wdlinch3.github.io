---
title: "Philadelphia & New Jersey"
map-group: scene
node-id: scene-philly-nj
tags:
  - hip-hop-field-guide
  - map/scene
---

# Philadelphia & New Jersey

Neighboring systems with their own MC, DJ, label, and club histories.

## Direct connections

- [[Recorded rap & electro]]
- [[New school]]
- [[Plural golden ages]]
- [[Regional systems]]
- [[Expansion & counterpublics]]
- [[Platform era]]

## Guide examples

- [The Sugarhill Gang — Rapper's Delight](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/03-recorded-rap.html#track-021)
- [Lady B — To the Beat Y'all](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/03-recorded-rap.html#track-024)
- [Schoolly D — P.S.K. What Does It Mean?](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/04-new-school.html#track-041)
- [Queen Latifah featuring Monie Love — Ladies First](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/05-plural-golden-ages.html#track-059)
- [Bahamadia — Uknowhowwedu](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/06-regional-systems.html#track-100)
- [The Roots — What They Do](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/07-expansion-counterpublics.html#track-107)
- [Lauryn Hill — Lost Ones](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/07-expansion-counterpublics.html#track-110)

[[_Start Here|Return to atlas index]]
