---
title: "Message & political rap"
map-group: practice
node-id: practice-message
tags:
  - hip-hop-field-guide
  - map/practice
---

# Message & political rap

Overlapping practices of social report, ethical argument, history, protest, and political education.

## Direct connections

- [[Before the name]]
- [[Recorded rap & electro]]
- [[New school]]
- [[Plural golden ages]]
- [[Regional systems]]
- [[Expansion & counterpublics]]
- [[South, mixtapes & producers]]
- [[Internet transition]]
- [[Fractured center]]
- [[Platform era]]
- [[Unfinished present]]

## Guide examples

- [The Last Poets — When the Revolution Comes](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/01-before-the-name.html#track-003)
- [The Watts Prophets — Dem Niggers Ain't Playing](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/01-before-the-name.html#track-006)
- [Gil Scott-Heron — The Revolution Will Not Be Televised](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/01-before-the-name.html#track-007)
- [Brother D with Collective Effort — How We Gonna Make the Black Nation Rise?](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/03-recorded-rap.html#track-027)
- [Grandmaster Flash and the Furious Five — The Message](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/03-recorded-rap.html#track-032)
- [Run-D.M.C. — It's Like That](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/03-recorded-rap.html#track-036)
- [MC Lyte — I Cram to Understand U (Sam)](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/04-new-school.html#track-049)

[[_Start Here|Return to atlas index]]
