---
title: "Recorded rap & electro"
map-group: era
node-id: HH03
tags:
  - hip-hop-field-guide
  - map/era
---

# Recorded rap & electro

Historical route block with 18 guide positions.

## Direct connections

- [[New York borough systems]]
- [[Philadelphia & New Jersey]]
- [[United Kingdom]]
- [[France & francophone circuits]]
- [[Latin American & Caribbean circuits]]
- [[Asian & Oceanian scenes]]
- [[DJ, breaks & turntablism]]
- [[Electro & machine funk]]
- [[Abstract, industrial & experimental]]
- [[Party, dance & crowd command]]
- [[Message & political rap]]
- [[Battle & braggadocio]]
- [[Storytelling & reportage]]
- [[Flow & lyrical formalism]]
- [[Singles & albums]]
- [[Dance, graffiti, radio & organizing beyond tracks]]

## Guide examples

- [The Sugarhill Gang — Rapper's Delight](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/03-recorded-rap.html#track-021)
- [The Fatback Band featuring King Tim III — King Tim III (Personality Jock)](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/03-recorded-rap.html#track-022)
- [The Sequence — Funk You Up](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/03-recorded-rap.html#track-023)
- [Lady B — To the Beat Y'all](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/03-recorded-rap.html#track-024)
- [Spoonie Gee — Spoonin Rap](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/03-recorded-rap.html#track-025)

[[_Start Here|Return to atlas index]]
