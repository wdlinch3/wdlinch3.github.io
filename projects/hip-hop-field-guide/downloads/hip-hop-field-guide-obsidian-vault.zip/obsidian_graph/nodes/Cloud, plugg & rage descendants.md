---
title: "Cloud, plugg & rage descendants"
map-group: production
node-id: prod-cloud-rage
tags:
  - hip-hop-field-guide
  - map/production
---

# Cloud, plugg & rage descendants

Atmosphere, producer-network circulation, synthetic timbre, and platform-era microgenre formation.

## Direct connections

- [[South, mixtapes & producers]]
- [[Internet transition]]
- [[Fractured center]]
- [[Platform era]]
- [[Unfinished present]]

## Guide examples

- [The Streets — Has It Come to This?](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/08-south-mixtapes-producers.html#track-147)
- [Drake — 9AM in Dallas](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/09-internet-transition.html#track-155)
- [Lil B — Wonton Soup](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/09-internet-transition.html#track-161)
- [Chief Keef featuring Lil Reese — I Don't Like](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/10-fractured-center.html#track-167)
- [Angel Haze — Werkin' Girls](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/10-fractured-center.html#track-168)
- [PNL — Le monde ou rien](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/10-fractured-center.html#track-183)
- [Tyler, the Creator — Yonkers](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/10-fractured-center.html#track-184)

[[_Start Here|Return to atlas index]]
