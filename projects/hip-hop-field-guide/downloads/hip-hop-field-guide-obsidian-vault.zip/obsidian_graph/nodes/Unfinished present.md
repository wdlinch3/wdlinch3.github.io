---
title: "Unfinished present"
map-group: era
node-id: HH12
tags:
  - hip-hop-field-guide
  - map/era
---

# Unfinished present

Historical route block with 18 guide positions.

## Direct connections

- [[New York borough systems]]
- [[Los Angeles & Compton]]
- [[Atlanta]]
- [[Memphis]]
- [[Midwest systems]]
- [[Florida]]
- [[United Kingdom]]
- [[France & francophone circuits]]
- [[African scenes]]
- [[Asian & Oceanian scenes]]
- [[DJ, breaks & turntablism]]
- [[Sampling & boom bap]]
- [[Trap lineages]]
- [[Drill migrations]]
- [[Melody & vocal processing]]
- [[Cloud, plugg & rage descendants]]
- [[Abstract, industrial & experimental]]
- [[Message & political rap]]
- [[Battle & braggadocio]]
- [[Storytelling & reportage]]
- [[Flow & lyrical formalism]]
- [[Gangsta & street rap]]
- [[Interiority, testimony & mourning]]
- [[Independent & counterpublic routes]]
- [[Mixtapes & street media]]
- [[Blogs & direct internet circulation]]
- [[Streaming & viral platforms]]
- [[Roc Marciano & minimalist revival]]
- [[Megan Thee Stallion & modern Houston women]]
- [[Hiplife, kwaito, Afro-trap & rap-afrobeats exchange]]
- [[Country rap & rural Southern hybrids]]
- [[Dance, graffiti, radio & organizing beyond tracks]]

## Guide examples

- [billy woods and Kenny Segal — Soft Landing](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/12-unfinished-present.html#track-203)
- [Boldy James and The Alchemist — Brickmile to Montana](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/12-unfinished-present.html#track-204)
- [Kendrick Lamar — The Heart Part 5](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/12-unfinished-present.html#track-205)
- [JID featuring Kenny Mason — Dance Now](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/12-unfinished-present.html#track-206)
- [Doechii — Nissan Altima](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/12-unfinished-present.html#track-207)

[[_Start Here|Return to atlas index]]
