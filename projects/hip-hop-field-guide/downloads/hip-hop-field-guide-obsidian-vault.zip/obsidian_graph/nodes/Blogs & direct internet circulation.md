---
title: "Blogs & direct internet circulation"
map-group: circulation
node-id: circ-internet
tags:
  - hip-hop-field-guide
  - map/circulation
---

# Blogs & direct internet circulation

Downloads, posts, direct uploads, and networked discovery that weaken some gates while creating new platform dependencies.

## Direct connections

- [[Internet transition]]
- [[Fractured center]]
- [[Platform era]]
- [[Unfinished present]]

## Guide examples

- [Kid Cudi — Day 'N' Nite](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/09-internet-transition.html#track-154)
- [Drake — 9AM in Dallas](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/09-internet-transition.html#track-155)
- [Lil B — Wonton Soup](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/09-internet-transition.html#track-161)
- [Chief Keef featuring Lil Reese — I Don't Like](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/10-fractured-center.html#track-167)
- [Angel Haze — Werkin' Girls](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/10-fractured-center.html#track-168)
- [Tyler, the Creator — Yonkers](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/10-fractured-center.html#track-184)
- [XXXTentacion — Look at Me!](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/11-platform-era.html#track-187)

[[_Start Here|Return to atlas index]]
