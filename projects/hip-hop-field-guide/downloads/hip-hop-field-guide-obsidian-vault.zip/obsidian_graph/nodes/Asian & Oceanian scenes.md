---
title: "Asian & Oceanian scenes"
map-group: scene
node-id: scene-asia-oceania
tags:
  - hip-hop-field-guide
  - map/scene
---

# Asian & Oceanian scenes

Locally rebuilt scenes connected through language, dance, media, migration, and platform circulation.

## Direct connections

- [[Recorded rap & electro]]
- [[Fractured center]]
- [[Platform era]]
- [[Unfinished present]]

## Guide examples

- [Yellow Magic Orchestra — Rap Phenomena](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/03-recorded-rap.html#track-035)
- [Keith Ape featuring JayAllDay Loota Okasian and Kohh — It G Ma](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/10-fractured-center.html#track-186)
- [Sampa the Great — Final Form](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/11-platform-era.html#track-199)
- [Barkaa — King Brown](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/12-unfinished-present.html#track-219)
- [Seedhe Maut — Namastute](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/12-unfinished-present.html#track-220)

[[_Start Here|Return to atlas index]]
