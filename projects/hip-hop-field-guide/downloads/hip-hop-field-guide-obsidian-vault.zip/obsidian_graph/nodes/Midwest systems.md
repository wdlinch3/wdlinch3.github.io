---
title: "Midwest systems"
map-group: scene
node-id: scene-midwest
tags:
  - hip-hop-field-guide
  - map/scene
---

# Midwest systems

Several independent city systems, from melodic ensemble flow to drill and Detroit’s conversational timing.

## Direct connections

- [[Regional systems]]
- [[Expansion & counterpublics]]
- [[South, mixtapes & producers]]
- [[Internet transition]]
- [[Fractured center]]
- [[Platform era]]
- [[Unfinished present]]

## Guide examples

- [Boss — Deeper](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/06-regional-systems.html#track-088)
- [Bone Thugs-N-Harmony — Tha Crossroads](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/06-regional-systems.html#track-089)
- [Common — I Used to Love H.E.R.](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/06-regional-systems.html#track-098)
- [Da Brat — Funkdafied](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/06-regional-systems.html#track-099)
- [Eminem featuring Dido — Stan](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/07-expansion-counterpublics.html#track-112)
- [Kanye West — Jesus Walks](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/08-south-mixtapes-producers.html#track-140)
- [J Dilla — Time: The Donut of the Heart](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/08-south-mixtapes-producers.html#track-143)

[[_Start Here|Return to atlas index]]
