---
title: "G-funk"
map-group: production
node-id: prod-gfunk
tags:
  - hip-hop-field-guide
  - map/production
---

# G-funk

A West Coast synthesis of elastic bass, melodic synth lines, funk memory, and relaxed rhythmic space.

## Direct connections

- [[Regional systems]]

## Guide examples

- [Dr. Dre featuring Snoop Doggy Dogg — Nuthin' but a 'G' Thang](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/06-regional-systems.html#track-081)
- [Snoop Doggy Dogg — Gin and Juice](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/06-regional-systems.html#track-082)
- [Da Brat — Funkdafied](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/06-regional-systems.html#track-099)

[[_Start Here|Return to atlas index]]
