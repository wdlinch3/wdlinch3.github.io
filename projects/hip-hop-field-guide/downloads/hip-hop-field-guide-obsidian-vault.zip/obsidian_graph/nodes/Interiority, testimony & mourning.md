---
title: "Interiority, testimony & mourning"
map-group: practice
node-id: practice-personal
tags:
  - hip-hop-field-guide
  - map/practice
---

# Interiority, testimony & mourning

Private testimony, psychological narration, grief, devotion, and self-analysis inside public performance.

## Direct connections

- [[Plural golden ages]]
- [[Regional systems]]
- [[Internet transition]]
- [[Fractured center]]
- [[Unfinished present]]

## Guide examples

- [Arrested Development — Tennessee](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/05-plural-golden-ages.html#track-074)
- [Bone Thugs-N-Harmony — Tha Crossroads](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/06-regional-systems.html#track-089)
- [Kid Cudi — Day 'N' Nite](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/09-internet-transition.html#track-154)
- [Blu & Exile — Dancing in the Rain](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/09-internet-transition.html#track-159)
- [Ana Tijoux — 1977](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/09-internet-transition.html#track-163)
- [Future — Codeine Crazy](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/10-fractured-center.html#track-169)
- [Earl Sweatshirt — Grief](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/10-fractured-center.html#track-176)

[[_Start Here|Return to atlas index]]
