---
title: "Fractured center"
map-group: era
node-id: HH10
tags:
  - hip-hop-field-guide
  - map/era
---

# Fractured center

Historical route block with 20 guide positions.

## Direct connections

- [[New York borough systems]]
- [[Los Angeles & Compton]]
- [[Atlanta]]
- [[Midwest systems]]
- [[United Kingdom]]
- [[France & francophone circuits]]
- [[Latin American & Caribbean circuits]]
- [[African scenes]]
- [[Asian & Oceanian scenes]]
- [[DJ, breaks & turntablism]]
- [[Electro & machine funk]]
- [[Sampling & boom bap]]
- [[Bass, bounce & dance systems]]
- [[Trap lineages]]
- [[Drill migrations]]
- [[Melody & vocal processing]]
- [[Cloud, plugg & rage descendants]]
- [[Abstract, industrial & experimental]]
- [[Party, dance & crowd command]]
- [[Message & political rap]]
- [[Battle & braggadocio]]
- [[Storytelling & reportage]]
- [[Flow & lyrical formalism]]
- [[Gangsta & street rap]]
- [[Interiority, testimony & mourning]]
- [[Independent & counterpublic routes]]
- [[Mixtapes & street media]]
- [[Blogs & direct internet circulation]]
- [[Streaming & viral platforms]]
- [[Dälek, clipping. & noise-rap branches]]
- [[Roc Marciano & minimalist revival]]
- [[Nipsey Hussle & modern West Coast independence]]
- [[Hiplife, kwaito, Afro-trap & rap-afrobeats exchange]]
- [[Country rap & rural Southern hybrids]]
- [[Dance, graffiti, radio & organizing beyond tracks]]

## Guide examples

- [Chief Keef featuring Lil Reese — I Don't Like](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/10-fractured-center.html#track-167)
- [Angel Haze — Werkin' Girls](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/10-fractured-center.html#track-168)
- [Future — Codeine Crazy](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/10-fractured-center.html#track-169)
- [Rich Gang featuring Young Thug and Rich Homie Quan — Lifestyle](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/10-fractured-center.html#track-170)
- [Migos — Fight Night](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/10-fractured-center.html#track-171)

[[_Start Here|Return to atlas index]]
