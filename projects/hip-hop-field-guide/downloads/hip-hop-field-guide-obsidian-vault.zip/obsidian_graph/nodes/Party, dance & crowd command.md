---
title: "Party, dance & crowd command"
map-group: practice
node-id: practice-party
tags:
  - hip-hop-field-guide
  - map/practice
---

# Party, dance & crowd command

A social function joining repeated instruction, audience response, bodily movement, and event control.

## Direct connections

- [[Before the name]]
- [[Live culture]]
- [[Recorded rap & electro]]
- [[New school]]
- [[Plural golden ages]]
- [[Regional systems]]
- [[Expansion & counterpublics]]
- [[South, mixtapes & producers]]
- [[Internet transition]]
- [[Fractured center]]

## Guide examples

- [The Jimmy Castor Bunch — It's Just Begun](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/01-before-the-name.html#track-008)
- [The Incredible Bongo Band — Apache](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/01-before-the-name.html#track-011)
- [Grandmaster Flash and the Furious Four MCs — Live at the Audubon Ballroom — December 23 1978](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/02-live-culture.html#track-013)
- [Furious Four — Live at Mitchell Gym](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/02-live-culture.html#track-014)
- [Funky Four — Live at unknown location](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/02-live-culture.html#track-015)
- [Afrika Bambaataa and associated crews — Birthday Party for DJ Kool Herc at 1590 Jerome Avenue](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/02-live-culture.html#track-016)
- [Grandmaster Flowers — Live at St. Marks Park Brooklyn](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/02-live-culture.html#track-017)

[[_Start Here|Return to atlas index]]
