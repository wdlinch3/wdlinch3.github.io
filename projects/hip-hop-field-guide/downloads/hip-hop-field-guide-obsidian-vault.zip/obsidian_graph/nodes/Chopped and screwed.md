---
title: "Chopped and screwed"
map-group: production
node-id: prod-screw
tags:
  - hip-hop-field-guide
  - map/production
---

# Chopped and screwed

A Houston listening and remix practice that changes tempo, repetition, pitch, memory, and social time.

## Direct connections

- [[Regional systems]]

## Guide examples

- [DJ Screw and Screwed Up Click — June 27th Freestyle](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/06-regional-systems.html#track-095)

[[_Start Here|Return to atlas index]]
