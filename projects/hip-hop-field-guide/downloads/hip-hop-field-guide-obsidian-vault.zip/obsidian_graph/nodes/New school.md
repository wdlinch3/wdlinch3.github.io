---
title: "New school"
map-group: era
node-id: HH04
tags:
  - hip-hop-field-guide
  - map/era
---

# New school

Historical route block with 18 guide positions.

## Direct connections

- [[New York borough systems]]
- [[Philadelphia & New Jersey]]
- [[Florida]]
- [[United Kingdom]]
- [[France & francophone circuits]]
- [[DJ, breaks & turntablism]]
- [[Electro & machine funk]]
- [[Sampling & boom bap]]
- [[Bass, bounce & dance systems]]
- [[Abstract, industrial & experimental]]
- [[Party, dance & crowd command]]
- [[Message & political rap]]
- [[Battle & braggadocio]]
- [[Storytelling & reportage]]
- [[Flow & lyrical formalism]]
- [[Gangsta & street rap]]
- [[Parties, radio & tapes]]
- [[Singles & albums]]
- [[Dance, graffiti, radio & organizing beyond tracks]]

## Guide examples

- [Run-D.M.C. — Sucker M.C.'s (Krush-Groove 1)](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/04-new-school.html#track-039)
- [LL Cool J — I Can't Live Without My Radio](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/04-new-school.html#track-040)
- [Schoolly D — P.S.K. What Does It Mean?](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/04-new-school.html#track-041)
- [Doug E. Fresh and the Get Fresh Crew — The Show](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/04-new-school.html#track-042)
- [Eric B. & Rakim — Eric B. Is President](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/04-new-school.html#track-043)

[[_Start Here|Return to atlas index]]
