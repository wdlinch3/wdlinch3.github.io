---
title: "Battle & braggadocio"
map-group: practice
node-id: practice-battle
tags:
  - hip-hop-field-guide
  - map/practice
---

# Battle & braggadocio

Competitive verbal display ranging from play and technical status claims to direct attack.

## Direct connections

- [[Recorded rap & electro]]
- [[New school]]
- [[Plural golden ages]]
- [[Expansion & counterpublics]]
- [[Internet transition]]
- [[Fractured center]]
- [[Unfinished present]]

## Guide examples

- [Roxanne Shanté — Roxanne's Revenge](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/03-recorded-rap.html#track-037)
- [Boogie Down Productions — South Bronx](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/04-new-school.html#track-044)
- [Ultramagnetic MC's — Ego Trippin'](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/04-new-school.html#track-046)
- [Hijack — Style Wars](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/04-new-school.html#track-056)
- [Big Daddy Kane — Ain't No Half-Steppin'](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/05-plural-golden-ages.html#track-064)
- [Main Source — Live at the Barbeque](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/05-plural-golden-ages.html#track-072)
- [Lauryn Hill — Lost Ones](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/07-expansion-counterpublics.html#track-110)

[[_Start Here|Return to atlas index]]
