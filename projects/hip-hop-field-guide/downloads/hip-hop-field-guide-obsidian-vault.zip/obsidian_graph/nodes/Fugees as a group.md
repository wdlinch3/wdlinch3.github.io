---
title: "Fugees as a group"
map-group: context
node-id: context-fugees
tags:
  - hip-hop-field-guide
  - map/context
---

# Fugees as a group

A major diaspora, ensemble, and crossover history only partly approached through Lauryn Hill’s solo exhibit.

## Direct connections

- [[Regional systems]]
- [[Expansion & counterpublics]]

## Guide examples

- [Read the omission challenge](https://wdlinch3.github.io/projects/hip-hop-field-guide/manifest_audit.html#omission-and-redundancy-challenge)

[[_Start Here|Return to atlas index]]
