---
title: "United Kingdom"
map-group: scene
node-id: scene-uk
tags:
  - hip-hop-field-guide
  - map/scene
---

# United Kingdom

A Black Atlantic route through rap, soundsystem practice, jungle, garage, grime, road rap, and drill exchange.

## Direct connections

- [[Before the name]]
- [[Recorded rap & electro]]
- [[New school]]
- [[Plural golden ages]]
- [[Expansion & counterpublics]]
- [[South, mixtapes & producers]]
- [[Internet transition]]
- [[Fractured center]]
- [[Platform era]]
- [[Unfinished present]]

## Guide examples

- [Cymande — Bra](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/01-before-the-name.html#track-010)
- [Newtrament — London Bridge Is Falling Down](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/03-recorded-rap.html#track-038)
- [Hijack — Style Wars](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/04-new-school.html#track-056)
- [London Posse — Money Mad](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/05-plural-golden-ages.html#track-079)
- [Monie Love — Monie in the Middle](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/05-plural-golden-ages.html#track-080)
- [Roots Manuva — Juggle Tings Proper](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/07-expansion-counterpublics.html#track-127)
- [M.I.A. — Galang](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/08-south-mixtapes-producers.html#track-145)

[[_Start Here|Return to atlas index]]
