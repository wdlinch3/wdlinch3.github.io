---
title: "Scarface solo route"
map-group: context
node-id: context-scarface
tags:
  - hip-hop-field-guide
  - map/context
---

# Scarface solo route

Houston narrative and political authority represented here by Geto Boys but not by a dedicated solo selection.

## Direct connections

- [[Plural golden ages]]
- [[Regional systems]]

## Guide examples

- [Read the omission challenge](https://wdlinch3.github.io/projects/hip-hop-field-guide/manifest_audit.html#omission-and-redundancy-challenge)

[[_Start Here|Return to atlas index]]
