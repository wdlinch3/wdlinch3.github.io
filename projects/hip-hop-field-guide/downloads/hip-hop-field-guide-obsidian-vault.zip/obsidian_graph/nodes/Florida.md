---
title: "Florida"
map-group: scene
node-id: scene-florida
tags:
  - hip-hop-field-guide
  - map/scene
---

# Florida

Miami bass and later decentralized platform scenes; one state does not imply one sound.

## Direct connections

- [[New school]]
- [[Internet transition]]
- [[Platform era]]
- [[Unfinished present]]

## Guide examples

- [2 Live Crew — Throw the D](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/04-new-school.html#track-048)
- [T-Pain featuring Yung Joc — Buy U a Drank (Shawty Snappin')](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/09-internet-transition.html#track-153)
- [XXXTentacion — Look at Me!](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/11-platform-era.html#track-187)
- [Doechii — Nissan Altima](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/12-unfinished-present.html#track-207)

[[_Start Here|Return to atlas index]]
