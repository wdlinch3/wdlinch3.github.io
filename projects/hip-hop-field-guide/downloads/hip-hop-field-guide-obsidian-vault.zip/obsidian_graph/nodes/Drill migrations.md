---
title: "Drill migrations"
map-group: production
node-id: prod-drill
tags:
  - hip-hop-field-guide
  - map/production
---

# Drill migrations

Connected but changing Chicago, UK, Brooklyn, and later drill grammars; migration alters rhythm and voice.

## Direct connections

- [[Fractured center]]
- [[Platform era]]
- [[Unfinished present]]

## Guide examples

- [Chief Keef featuring Lil Reese — I Don't Like](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/10-fractured-center.html#track-167)
- [Pop Smoke — Dior](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/11-platform-era.html#track-201)
- [Headie One featuring AJ Tracey and Stormzy — Ain't It Different](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/12-unfinished-present.html#track-213)

[[_Start Here|Return to atlas index]]
