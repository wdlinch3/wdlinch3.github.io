---
title: "Independent labels & regional business"
map-group: circulation
node-id: circ-independent
tags:
  - hip-hop-field-guide
  - map/circulation
---

# Independent labels & regional business

Local labels, stores, crews, and repeated regional circulation that sustain scenes without a single national gate.

## Direct connections

- [[Plural golden ages]]
- [[Regional systems]]
- [[Expansion & counterpublics]]

## Guide examples

- [N.W.A — Straight Outta Compton](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/05-plural-golden-ages.html#track-066)
- [Three 6 Mafia — Da Summa](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/06-regional-systems.html#track-094)
- [Master P featuring Fiend Mia X Mystikal and Silkk the Shocker — Make 'Em Say Uhh!](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/07-expansion-counterpublics.html#track-123)

[[_Start Here|Return to atlas index]]
