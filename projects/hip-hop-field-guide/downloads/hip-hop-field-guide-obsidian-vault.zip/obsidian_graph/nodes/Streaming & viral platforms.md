---
title: "Streaming & viral platforms"
map-group: circulation
node-id: circ-platform
tags:
  - hip-hop-field-guide
  - map/circulation
---

# Streaming & viral platforms

Platforms shape song length, discovery, visual identity, metrics, and access without producing one shared musical style.

## Direct connections

- [[Expansion & counterpublics]]
- [[Fractured center]]
- [[Platform era]]
- [[Unfinished present]]

## Guide examples

- [The Roots — What They Do](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/07-expansion-counterpublics.html#track-107)
- [Missy Elliott — The Rain (Supa Dupa Fly)](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/07-expansion-counterpublics.html#track-111)
- [Keith Ape featuring JayAllDay Loota Okasian and Kohh — It G Ma](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/10-fractured-center.html#track-186)
- [XXXTentacion — Look at Me!](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/11-platform-era.html#track-187)
- [Kendrick Lamar — The Heart Part 5](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/12-unfinished-present.html#track-205)

[[_Start Here|Return to atlas index]]
