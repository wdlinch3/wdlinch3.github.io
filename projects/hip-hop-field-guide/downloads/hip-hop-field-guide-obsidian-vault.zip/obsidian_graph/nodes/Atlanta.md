---
title: "Atlanta"
map-group: scene
node-id: scene-atlanta
tags:
  - hip-hop-field-guide
  - map/scene
---

# Atlanta

Bass, Organized Noize, crunk, snap, trap, and later melodic systems built through changing local infrastructures.

## Direct connections

- [[Plural golden ages]]
- [[Regional systems]]
- [[Expansion & counterpublics]]
- [[South, mixtapes & producers]]
- [[Internet transition]]
- [[Fractured center]]
- [[Platform era]]
- [[Unfinished present]]

## Guide examples

- [Arrested Development — Tennessee](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/05-plural-golden-ages.html#track-074)
- [Outkast featuring CeeLo — Git Up, Git Out](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/06-regional-systems.html#track-091)
- [Goodie Mob — Cell Therapy](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/06-regional-systems.html#track-092)
- [Da Brat — Funkdafied](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/06-regional-systems.html#track-099)
- [Outkast — Rosa Parks](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/07-expansion-counterpublics.html#track-121)
- [Lil Jon & the East Side Boyz featuring Ying Yang Twins — Get Low](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/08-south-mixtapes-producers.html#track-132)
- [T.I. — 24's](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/08-south-mixtapes-producers.html#track-133)

[[_Start Here|Return to atlas index]]
