---
title: "Platform era"
map-group: era
node-id: HH11
tags:
  - hip-hop-field-guide
  - map/era
---

# Platform era

Historical route block with 16 guide positions.

## Direct connections

- [[New York borough systems]]
- [[Philadelphia & New Jersey]]
- [[Los Angeles & Compton]]
- [[Atlanta]]
- [[Houston]]
- [[Midwest systems]]
- [[Florida]]
- [[United Kingdom]]
- [[Latin American & Caribbean circuits]]
- [[African scenes]]
- [[Asian & Oceanian scenes]]
- [[DJ, breaks & turntablism]]
- [[Sampling & boom bap]]
- [[Trap lineages]]
- [[Drill migrations]]
- [[Melody & vocal processing]]
- [[Cloud, plugg & rage descendants]]
- [[Abstract, industrial & experimental]]
- [[Message & political rap]]
- [[Flow & lyrical formalism]]
- [[Gangsta & street rap]]
- [[Independent & counterpublic routes]]
- [[Parties, radio & tapes]]
- [[Mixtapes & street media]]
- [[Blogs & direct internet circulation]]
- [[Streaming & viral platforms]]
- [[Dälek, clipping. & noise-rap branches]]
- [[Nipsey Hussle & modern West Coast independence]]
- [[Megan Thee Stallion & modern Houston women]]
- [[Hiplife, kwaito, Afro-trap & rap-afrobeats exchange]]
- [[Country rap & rural Southern hybrids]]
- [[Dance, graffiti, radio & organizing beyond tracks]]

## Guide examples

- [XXXTentacion — Look at Me!](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/11-platform-era.html#track-187)
- [Lil Uzi Vert — XO TOUR Llif3](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/11-platform-era.html#track-188)
- [Playboi Carti — Magnolia](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/11-platform-era.html#track-189)
- [Juice WRLD — Lucid Dreams](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/11-platform-era.html#track-190)
- [Lil Peep — Benz Truck (гелик)](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/11-platform-era.html#track-191)

[[_Start Here|Return to atlas index]]
