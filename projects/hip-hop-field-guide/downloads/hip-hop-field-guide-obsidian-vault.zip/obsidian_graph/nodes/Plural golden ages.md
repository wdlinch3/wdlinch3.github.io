---
title: "Plural golden ages"
map-group: era
node-id: HH05
tags:
  - hip-hop-field-guide
  - map/era
---

# Plural golden ages

Historical route block with 24 guide positions.

## Direct connections

- [[New York borough systems]]
- [[Philadelphia & New Jersey]]
- [[Los Angeles & Compton]]
- [[Bay Area]]
- [[Atlanta]]
- [[Houston]]
- [[United Kingdom]]
- [[France & francophone circuits]]
- [[Latin American & Caribbean circuits]]
- [[African scenes]]
- [[DJ, breaks & turntablism]]
- [[Sampling & boom bap]]
- [[Melody & vocal processing]]
- [[Abstract, industrial & experimental]]
- [[Party, dance & crowd command]]
- [[Message & political rap]]
- [[Battle & braggadocio]]
- [[Storytelling & reportage]]
- [[Flow & lyrical formalism]]
- [[Gangsta & street rap]]
- [[Interiority, testimony & mourning]]
- [[Independent & counterpublic routes]]
- [[Singles & albums]]
- [[Independent labels & regional business]]
- [[Scarface solo route]]
- [[Dance, graffiti, radio & organizing beyond tracks]]

## Guide examples

- [Public Enemy — Fight the Power](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/05-plural-golden-ages.html#track-057)
- [Boogie Down Productions — You Must Learn](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/05-plural-golden-ages.html#track-058)
- [Queen Latifah featuring Monie Love — Ladies First](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/05-plural-golden-ages.html#track-059)
- [De La Soul — Me Myself and I](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/05-plural-golden-ages.html#track-060)
- [Jungle Brothers — Straight Out the Jungle](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/05-plural-golden-ages.html#track-061)

[[_Start Here|Return to atlas index]]
