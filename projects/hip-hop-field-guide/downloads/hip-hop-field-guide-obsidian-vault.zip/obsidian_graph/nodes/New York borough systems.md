---
title: "New York borough systems"
map-group: scene
node-id: scene-ny
tags:
  - hip-hop-field-guide
  - map/scene
---

# New York borough systems

Connected but nonidentical borough histories of parties, radio, labels, crews, studios, and audiences.

## Direct connections

- [[Before the name]]
- [[Live culture]]
- [[Recorded rap & electro]]
- [[New school]]
- [[Plural golden ages]]
- [[Regional systems]]
- [[Expansion & counterpublics]]
- [[South, mixtapes & producers]]
- [[Internet transition]]
- [[Fractured center]]
- [[Platform era]]
- [[Unfinished present]]

## Guide examples

- [The Last Poets — When the Revolution Comes](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/01-before-the-name.html#track-003)
- [Gil Scott-Heron — The Revolution Will Not Be Televised](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/01-before-the-name.html#track-007)
- [The Jimmy Castor Bunch — It's Just Begun](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/01-before-the-name.html#track-008)
- [Lightnin' Rod — Sport](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/01-before-the-name.html#track-012)
- [Grandmaster Flash and the Furious Four MCs — Live at the Audubon Ballroom — December 23 1978](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/02-live-culture.html#track-013)
- [Furious Four — Live at Mitchell Gym](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/02-live-culture.html#track-014)
- [Funky Four — Live at unknown location](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/02-live-culture.html#track-015)

[[_Start Here|Return to atlas index]]
