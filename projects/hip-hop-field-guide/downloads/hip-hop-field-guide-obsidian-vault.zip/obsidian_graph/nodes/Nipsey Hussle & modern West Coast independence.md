---
title: "Nipsey Hussle & modern West Coast independence"
map-group: context
node-id: context-nipsey
tags:
  - hip-hop-field-guide
  - map/context
---

# Nipsey Hussle & modern West Coast independence

Mixtape, local business, community investment, and West Coast independence without a dedicated current track.

## Direct connections

- [[Fractured center]]
- [[Platform era]]

## Guide examples

- [Read the omission challenge](https://wdlinch3.github.io/projects/hip-hop-field-guide/manifest_audit.html#omission-and-redundancy-challenge)

[[_Start Here|Return to atlas index]]
