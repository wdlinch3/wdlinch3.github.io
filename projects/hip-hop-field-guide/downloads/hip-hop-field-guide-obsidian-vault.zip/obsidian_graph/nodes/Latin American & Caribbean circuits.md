---
title: "Latin American & Caribbean circuits"
map-group: scene
node-id: scene-latin
tags:
  - hip-hop-field-guide
  - map/scene
---

# Latin American & Caribbean circuits

Local-language rap and reciprocal exchange with reggae, reggaetón, funk carioca, and distinct national scenes.

## Direct connections

- [[Recorded rap & electro]]
- [[Plural golden ages]]
- [[Regional systems]]
- [[Expansion & counterpublics]]
- [[South, mixtapes & producers]]
- [[Internet transition]]
- [[Fractured center]]
- [[Platform era]]

## Guide examples

- [Mean Machine — Disco Dream](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/03-recorded-rap.html#track-031)
- [Cypress Hill — How I Could Just Kill a Man](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/05-plural-golden-ages.html#track-075)
- [Vico C — La Recta Final](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/05-plural-golden-ages.html#track-077)
- [London Posse — Money Mad](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/05-plural-golden-ages.html#track-079)
- [Racionais MC's — Homem na Estrada](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/06-regional-systems.html#track-103)
- [Control Machete — ¿Comprendes Mendes?](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/07-expansion-counterpublics.html#track-125)
- [Racionais MC's — Diário de um Detento](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/07-expansion-counterpublics.html#track-126)

[[_Start Here|Return to atlas index]]
