---
title: "Trap lineages"
map-group: production
node-id: prod-trap
tags:
  - hip-hop-field-guide
  - map/production
---

# Trap lineages

Overlapping Southern lineages of drum programming, synthesizer space, street narrative, and producer networks.

## Direct connections

- [[South, mixtapes & producers]]
- [[Internet transition]]
- [[Fractured center]]
- [[Platform era]]
- [[Unfinished present]]

## Guide examples

- [T.I. — 24's](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/08-south-mixtapes-producers.html#track-133)
- [Young Jeezy featuring Jay-Z — Go Crazy](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/08-south-mixtapes-producers.html#track-134)
- [Gucci Mane — Trap House](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/08-south-mixtapes-producers.html#track-135)
- [Waka Flocka Flame — Hard in da Paint](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/09-internet-transition.html#track-156)
- [Future — Codeine Crazy](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/10-fractured-center.html#track-169)
- [Rich Gang featuring Young Thug and Rich Homie Quan — Lifestyle](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/10-fractured-center.html#track-170)
- [Migos — Fight Night](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/10-fractured-center.html#track-171)

[[_Start Here|Return to atlas index]]
