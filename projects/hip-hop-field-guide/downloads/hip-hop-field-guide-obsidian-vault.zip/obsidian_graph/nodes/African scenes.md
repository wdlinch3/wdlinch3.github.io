---
title: "African scenes"
map-group: scene
node-id: scene-africa
tags:
  - hip-hop-field-guide
  - map/scene
---

# African scenes

Many local infrastructures and languages; this node resists treating a continent as one genre.

## Direct connections

- [[Plural golden ages]]
- [[Regional systems]]
- [[Expansion & counterpublics]]
- [[South, mixtapes & producers]]
- [[Internet transition]]
- [[Fractured center]]
- [[Platform era]]
- [[Unfinished present]]

## Guide examples

- [Prophets of Da City — Our World](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/05-plural-golden-ages.html#track-078)
- [Prophets of Da City — Never Again](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/06-regional-systems.html#track-104)
- [Positive Black Soul — Boul ma mine](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/06-regional-systems.html#track-106)
- [Positive Black Soul — New York, Paris, Dakar](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/07-expansion-counterpublics.html#track-128)
- [Jean Grae — Hater's Anthem](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/08-south-mixtapes-producers.html#track-138)
- [K'naan — What's Hardcore?](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/08-south-mixtapes-producers.html#track-149)
- [Daara J — Exodus](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/08-south-mixtapes-producers.html#track-150)

[[_Start Here|Return to atlas index]]
