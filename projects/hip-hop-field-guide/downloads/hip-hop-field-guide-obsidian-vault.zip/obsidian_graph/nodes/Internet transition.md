---
title: "Internet transition"
map-group: era
node-id: HH09
tags:
  - hip-hop-field-guide
  - map/era
---

# Internet transition

Historical route block with 16 guide positions.

## Direct connections

- [[New York borough systems]]
- [[Los Angeles & Compton]]
- [[Bay Area]]
- [[Atlanta]]
- [[New Orleans]]
- [[Midwest systems]]
- [[Florida]]
- [[United Kingdom]]
- [[Latin American & Caribbean circuits]]
- [[African scenes]]
- [[DJ, breaks & turntablism]]
- [[Electro & machine funk]]
- [[Bass, bounce & dance systems]]
- [[Trap lineages]]
- [[Melody & vocal processing]]
- [[Cloud, plugg & rage descendants]]
- [[Abstract, industrial & experimental]]
- [[Party, dance & crowd command]]
- [[Message & political rap]]
- [[Battle & braggadocio]]
- [[Storytelling & reportage]]
- [[Flow & lyrical formalism]]
- [[Gangsta & street rap]]
- [[Interiority, testimony & mourning]]
- [[Independent & counterpublic routes]]
- [[Singles & albums]]
- [[Mixtapes & street media]]
- [[Blogs & direct internet circulation]]
- [[Roc Marciano & minimalist revival]]
- [[Hiplife, kwaito, Afro-trap & rap-afrobeats exchange]]
- [[Country rap & rural Southern hybrids]]
- [[Dance, graffiti, radio & organizing beyond tracks]]

## Guide examples

- [Lil Wayne — A Milli](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/09-internet-transition.html#track-151)
- [Kanye West — Say You Will](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/09-internet-transition.html#track-152)
- [T-Pain featuring Yung Joc — Buy U a Drank (Shawty Snappin')](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/09-internet-transition.html#track-153)
- [Kid Cudi — Day 'N' Nite](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/09-internet-transition.html#track-154)
- [Drake — 9AM in Dallas](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/09-internet-transition.html#track-155)

[[_Start Here|Return to atlas index]]
