---
title: "Live culture"
map-group: era
node-id: HH02
tags:
  - hip-hop-field-guide
  - map/era
---

# Live culture

Historical route block with 8 guide positions.

## Direct connections

- [[New York borough systems]]
- [[DJ, breaks & turntablism]]
- [[Bass, bounce & dance systems]]
- [[Abstract, industrial & experimental]]
- [[Party, dance & crowd command]]
- [[Flow & lyrical formalism]]
- [[Parties, radio & tapes]]
- [[Singles & albums]]
- [[Dance, graffiti, radio & organizing beyond tracks]]

## Guide examples

- [Grandmaster Flash and the Furious Four MCs — Live at the Audubon Ballroom — December 23 1978](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/02-live-culture.html#track-013)
- [Furious Four — Live at Mitchell Gym](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/02-live-culture.html#track-014)
- [Funky Four — Live at unknown location](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/02-live-culture.html#track-015)
- [Afrika Bambaataa and associated crews — Birthday Party for DJ Kool Herc at 1590 Jerome Avenue](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/02-live-culture.html#track-016)
- [Grandmaster Flowers — Live at St. Marks Park Brooklyn](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/02-live-culture.html#track-017)

[[_Start Here|Return to atlas index]]
