---
title: "Abstract, industrial & experimental"
map-group: production
node-id: prod-experimental
tags:
  - hip-hop-field-guide
  - map/production
---

# Abstract, industrial & experimental

Unusual timbre, disrupted narrative, noise, nonstandard form, and deliberate damage to familiar rap expectations.

## Direct connections

- [[Before the name]]
- [[Live culture]]
- [[Recorded rap & electro]]
- [[New school]]
- [[Plural golden ages]]
- [[Regional systems]]
- [[Expansion & counterpublics]]
- [[South, mixtapes & producers]]
- [[Internet transition]]
- [[Fractured center]]
- [[Platform era]]
- [[Unfinished present]]

## Guide examples

- [U-Roy — Wake the Town](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/01-before-the-name.html#track-004)
- [Funky Four — Live at unknown location](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/02-live-culture.html#track-015)
- [Grandmaster Flowers — Live at St. Marks Park Brooklyn](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/02-live-culture.html#track-017)
- [Kurtis Blow — The Breaks](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/03-recorded-rap.html#track-026)
- [Grandmaster Flash and the Furious Five — The Message](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/03-recorded-rap.html#track-032)
- [Yellow Magic Orchestra — Rap Phenomena](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/03-recorded-rap.html#track-035)
- [Doug E. Fresh and the Get Fresh Crew — The Show](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/04-new-school.html#track-042)

[[_Start Here|Return to atlas index]]
