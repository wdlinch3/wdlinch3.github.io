---
title: "South, mixtapes & producers"
map-group: era
node-id: HH08
tags:
  - hip-hop-field-guide
  - map/era
---

# South, mixtapes & producers

Historical route block with 22 guide positions.

## Direct connections

- [[New York borough systems]]
- [[Los Angeles & Compton]]
- [[Atlanta]]
- [[New Orleans]]
- [[Midwest systems]]
- [[United Kingdom]]
- [[France & francophone circuits]]
- [[Latin American & Caribbean circuits]]
- [[African scenes]]
- [[Electro & machine funk]]
- [[Sampling & boom bap]]
- [[Bass, bounce & dance systems]]
- [[Trap lineages]]
- [[Cloud, plugg & rage descendants]]
- [[Abstract, industrial & experimental]]
- [[Party, dance & crowd command]]
- [[Message & political rap]]
- [[Storytelling & reportage]]
- [[Flow & lyrical formalism]]
- [[Gangsta & street rap]]
- [[Independent & counterpublic routes]]
- [[Mixtapes & street media]]
- [[Dälek, clipping. & noise-rap branches]]
- [[Hiplife, kwaito, Afro-trap & rap-afrobeats exchange]]
- [[Country rap & rural Southern hybrids]]
- [[Dance, graffiti, radio & organizing beyond tracks]]

## Guide examples

- [Jay-Z — U Don't Know](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/08-south-mixtapes-producers.html#track-129)
- [Clipse — Grindin'](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/08-south-mixtapes-producers.html#track-130)
- [Missy Elliott — Work It](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/08-south-mixtapes-producers.html#track-131)
- [Lil Jon & the East Side Boyz featuring Ying Yang Twins — Get Low](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/08-south-mixtapes-producers.html#track-132)
- [T.I. — 24's](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/08-south-mixtapes-producers.html#track-133)

[[_Start Here|Return to atlas index]]
