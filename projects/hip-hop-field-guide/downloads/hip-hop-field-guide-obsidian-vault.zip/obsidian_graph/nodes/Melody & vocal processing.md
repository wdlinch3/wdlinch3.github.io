---
title: "Melody & vocal processing"
map-group: production
node-id: prod-melody
tags:
  - hip-hop-field-guide
  - map/production
---

# Melody & vocal processing

The voice operates as narrator, hook, texture, and processed instrument rather than as an unaltered speech channel.

## Direct connections

- [[Plural golden ages]]
- [[Regional systems]]
- [[Expansion & counterpublics]]
- [[Internet transition]]
- [[Fractured center]]
- [[Platform era]]
- [[Unfinished present]]

## Guide examples

- [Arrested Development — Tennessee](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/05-plural-golden-ages.html#track-074)
- [Bone Thugs-N-Harmony — Tha Crossroads](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/06-regional-systems.html#track-089)
- [IAM — Je danse le mia](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/06-regional-systems.html#track-101)
- [DJ Shadow — Midnight in a Perfect World](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/07-expansion-counterpublics.html#track-118)
- [Racionais MC's — Diário de um Detento](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/07-expansion-counterpublics.html#track-126)
- [Kanye West — Say You Will](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/09-internet-transition.html#track-152)
- [T-Pain featuring Yung Joc — Buy U a Drank (Shawty Snappin')](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/09-internet-transition.html#track-153)

[[_Start Here|Return to atlas index]]
