---
title: "Live bands & instruments"
map-group: production
node-id: prod-live
tags:
  - hip-hop-field-guide
  - map/production
---

# Live bands & instruments

Ensemble performance and instrumental interplay inside a field often narrated through samples and machines.

## Direct connections

- [[Expansion & counterpublics]]

## Guide examples

- [The Roots — What They Do](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/07-expansion-counterpublics.html#track-107)
- [Outkast — Rosa Parks](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/07-expansion-counterpublics.html#track-121)

[[_Start Here|Return to atlas index]]
