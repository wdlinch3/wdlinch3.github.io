---
title: "Bass, bounce & dance systems"
map-group: production
node-id: prod-bass-bounce
tags:
  - hip-hop-field-guide
  - map/production
---

# Bass, bounce & dance systems

Distinct dance-centered systems whose repeated vocal and rhythmic instructions assume local movement practices.

## Direct connections

- [[Live culture]]
- [[New school]]
- [[Regional systems]]
- [[Expansion & counterpublics]]
- [[South, mixtapes & producers]]
- [[Internet transition]]
- [[Fractured center]]

## Guide examples

- [DJ Hollywood — Live club routine](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/02-live-culture.html#track-019)
- [2 Live Crew — Throw the D](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/04-new-school.html#track-048)
- [DJ Jimi feat. Juvenile — Bounce (For the Juvenile)](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/06-regional-systems.html#track-096)
- [DJ Jubilee — Do the Jubilee All](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/06-regional-systems.html#track-097)
- [dead prez — Hip-Hop](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/07-expansion-counterpublics.html#track-109)
- [Roots Manuva — Juggle Tings Proper](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/07-expansion-counterpublics.html#track-127)
- [Lil Jon & the East Side Boyz featuring Ying Yang Twins — Get Low](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/08-south-mixtapes-producers.html#track-132)

[[_Start Here|Return to atlas index]]
