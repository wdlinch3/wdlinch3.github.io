---
title: "Memphis"
map-group: scene
node-id: scene-memphis
tags:
  - hip-hop-field-guide
  - map/scene
---

# Memphis

Cassette circulation, dark drum-machine production, collective styles, and later internet afterlives.

## Direct connections

- [[Regional systems]]
- [[Unfinished present]]

## Guide examples

- [Three 6 Mafia — Da Summa](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/06-regional-systems.html#track-094)
- [GloRilla and Hitkidd — F.N.F. (Let's Go)](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/12-unfinished-present.html#track-212)

[[_Start Here|Return to atlas index]]
