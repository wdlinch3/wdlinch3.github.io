---
title: "Hiplife, kwaito, Afro-trap & rap/afrobeats exchange"
map-group: context
node-id: context-african-neighbors
tags:
  - hip-hop-field-guide
  - map/context
---

# Hiplife, kwaito, Afro-trap & rap/afrobeats exchange

Important neighboring African systems that cannot be collapsed into one rap genre or a handful of national examples.

## Direct connections

- [[Expansion & counterpublics]]
- [[South, mixtapes & producers]]
- [[Internet transition]]
- [[Fractured center]]
- [[Platform era]]
- [[Unfinished present]]

## Guide examples

- [Read the omission challenge](https://wdlinch3.github.io/projects/hip-hop-field-guide/manifest_audit.html#omission-and-redundancy-challenge)

[[_Start Here|Return to atlas index]]
