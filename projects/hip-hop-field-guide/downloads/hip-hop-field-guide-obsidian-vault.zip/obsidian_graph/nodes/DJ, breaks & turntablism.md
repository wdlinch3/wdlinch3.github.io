---
title: "DJ, breaks & turntablism"
map-group: production
node-id: prod-dj-breaks
tags:
  - hip-hop-field-guide
  - map/production
---

# DJ, breaks & turntablism

Selection, isolation, cutting, repetition, scratching, and composition with recorded sound.

## Direct connections

- [[Before the name]]
- [[Live culture]]
- [[Recorded rap & electro]]
- [[New school]]
- [[Plural golden ages]]
- [[Regional systems]]
- [[Expansion & counterpublics]]
- [[Internet transition]]
- [[Fractured center]]
- [[Platform era]]
- [[Unfinished present]]

## Guide examples

- [James Brown — Funky Drummer](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/01-before-the-name.html#track-005)
- [The Jimmy Castor Bunch — It's Just Begun](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/01-before-the-name.html#track-008)
- [Babe Ruth — The Mexican](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/01-before-the-name.html#track-009)
- [Cymande — Bra](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/01-before-the-name.html#track-010)
- [The Incredible Bongo Band — Apache](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/01-before-the-name.html#track-011)
- [Grandmaster Flash and the Furious Four MCs — Live at the Audubon Ballroom — December 23 1978](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/02-live-culture.html#track-013)
- [Afrika Bambaataa and associated crews — Birthday Party for DJ Kool Herc at 1590 Jerome Avenue](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/02-live-culture.html#track-016)

[[_Start Here|Return to atlas index]]
