---
title: "Roc Marciano & minimalist revival"
map-group: context
node-id: context-roc
tags:
  - hip-hop-field-guide
  - map/context
---

# Roc Marciano & minimalist revival

A major independent minimalist street-rap lineage that could reorganize the 2010s counter-history.

## Direct connections

- [[Internet transition]]
- [[Fractured center]]
- [[Unfinished present]]

## Guide examples

- [Read the omission challenge](https://wdlinch3.github.io/projects/hip-hop-field-guide/manifest_audit.html#omission-and-redundancy-challenge)

[[_Start Here|Return to atlas index]]
