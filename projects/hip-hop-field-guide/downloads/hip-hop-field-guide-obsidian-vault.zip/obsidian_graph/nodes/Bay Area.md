---
title: "Bay Area"
map-group: scene
node-id: scene-bay
tags:
  - hip-hop-field-guide
  - map/scene
---

# Bay Area

Independent business, political rap, and distinctive local vocal and production lineages.

## Direct connections

- [[Plural golden ages]]
- [[Regional systems]]
- [[Expansion & counterpublics]]
- [[Internet transition]]

## Guide examples

- [Too $hort — The Ghetto](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/05-plural-golden-ages.html#track-070)
- [The Coup — Dig It!](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/06-regional-systems.html#track-090)
- [DJ Shadow — Midnight in a Perfect World](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/07-expansion-counterpublics.html#track-118)
- [Invisibl Skratch Piklz — Invasion of the Octopus People](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/07-expansion-counterpublics.html#track-119)
- [Lil B — Wonton Soup](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/09-internet-transition.html#track-161)

[[_Start Here|Return to atlas index]]
