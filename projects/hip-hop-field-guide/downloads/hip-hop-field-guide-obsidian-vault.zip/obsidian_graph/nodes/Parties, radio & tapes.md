---
title: "Parties, radio & tapes"
map-group: circulation
node-id: circ-live
tags:
  - hip-hop-field-guide
  - map/circulation
---

# Parties, radio & tapes

Event recordings, broadcasts, copies, and crowd memory circulating before or beyond ordinary releases.

## Direct connections

- [[Live culture]]
- [[New school]]
- [[Expansion & counterpublics]]
- [[Platform era]]

## Guide examples

- [Grandmaster Flash and the Furious Four MCs — Live at the Audubon Ballroom — December 23 1978](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/02-live-culture.html#track-013)
- [Furious Four — Live at Mitchell Gym](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/02-live-culture.html#track-014)
- [Funky Four — Live at unknown location](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/02-live-culture.html#track-015)
- [Afrika Bambaataa and associated crews — Birthday Party for DJ Kool Herc at 1590 Jerome Avenue](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/02-live-culture.html#track-016)
- [Grandmaster Flowers — Live at St. Marks Park Brooklyn](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/02-live-culture.html#track-017)
- [Cold Crush Four and Disco Enforcers — Live at T-Connection](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/02-live-culture.html#track-018)
- [DJ Hollywood — Live club routine](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/02-live-culture.html#track-019)

[[_Start Here|Return to atlas index]]
