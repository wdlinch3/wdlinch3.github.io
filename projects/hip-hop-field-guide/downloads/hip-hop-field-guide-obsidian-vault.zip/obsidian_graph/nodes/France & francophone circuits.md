---
title: "France & francophone circuits"
map-group: scene
node-id: scene-france
tags:
  - hip-hop-field-guide
  - map/scene
---

# France & francophone circuits

French-language and multilingual scenes shaped by radio, suburbs, migration, local politics, and exchange with African circuits.

## Direct connections

- [[Recorded rap & electro]]
- [[New school]]
- [[Plural golden ages]]
- [[Regional systems]]
- [[Expansion & counterpublics]]
- [[South, mixtapes & producers]]
- [[Fractured center]]
- [[Unfinished present]]

## Guide examples

- [Chagrin d'amour — Chacun fait (c'qui lui plaît)](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/03-recorded-rap.html#track-034)
- [Dee Nasty — Paname City Rappin'](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/04-new-school.html#track-054)
- [Lionel D — Y'a pas de problème](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/04-new-school.html#track-055)
- [IAM — Red Black and Green](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/05-plural-golden-ages.html#track-076)
- [IAM — Je danse le mia](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/06-regional-systems.html#track-101)
- [MC Solaar — Nouveau Western](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/06-regional-systems.html#track-102)
- [Positive Black Soul — Boul ma mine](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/06-regional-systems.html#track-106)

[[_Start Here|Return to atlas index]]
