---
title: "Independent & counterpublic routes"
map-group: practice
node-id: practice-counterpublic
tags:
  - hip-hop-field-guide
  - map/practice
---

# Independent & counterpublic routes

Different ways of building audiences and authority outside, beside, or against an imagined mainstream.

## Direct connections

- [[Plural golden ages]]
- [[Expansion & counterpublics]]
- [[South, mixtapes & producers]]
- [[Internet transition]]
- [[Fractured center]]
- [[Platform era]]
- [[Unfinished present]]

## Guide examples

- [Queen Latifah featuring Monie Love — Ladies First](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/05-plural-golden-ages.html#track-059)
- [De La Soul — Me Myself and I](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/05-plural-golden-ages.html#track-060)
- [Yo-Yo featuring Ice Cube — You Can't Play with My Yo-Yo](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/05-plural-golden-ages.html#track-073)
- [Company Flow — 8 Steps to Perfection](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/07-expansion-counterpublics.html#track-113)
- [MF DOOM — Doomsday](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/07-expansion-counterpublics.html#track-115)
- [Master P featuring Fiend Mia X Mystikal and Silkk the Shocker — Make 'Em Say Uhh!](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/07-expansion-counterpublics.html#track-123)
- [Gucci Mane — Trap House](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/08-south-mixtapes-producers.html#track-135)

[[_Start Here|Return to atlas index]]
