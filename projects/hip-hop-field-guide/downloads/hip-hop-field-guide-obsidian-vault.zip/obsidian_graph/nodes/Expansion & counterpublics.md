---
title: "Expansion & counterpublics"
map-group: era
node-id: HH07
tags:
  - hip-hop-field-guide
  - map/era
---

# Expansion & counterpublics

Historical route block with 22 guide positions.

## Direct connections

- [[New York borough systems]]
- [[Philadelphia & New Jersey]]
- [[Bay Area]]
- [[Atlanta]]
- [[New Orleans]]
- [[Midwest systems]]
- [[United Kingdom]]
- [[France & francophone circuits]]
- [[Latin American & Caribbean circuits]]
- [[African scenes]]
- [[DJ, breaks & turntablism]]
- [[Sampling & boom bap]]
- [[Bass, bounce & dance systems]]
- [[Melody & vocal processing]]
- [[Abstract, industrial & experimental]]
- [[Live bands & instruments]]
- [[Party, dance & crowd command]]
- [[Message & political rap]]
- [[Battle & braggadocio]]
- [[Storytelling & reportage]]
- [[Flow & lyrical formalism]]
- [[Gangsta & street rap]]
- [[Independent & counterpublic routes]]
- [[Parties, radio & tapes]]
- [[Singles & albums]]
- [[Independent labels & regional business]]
- [[Mixtapes & street media]]
- [[Streaming & viral platforms]]
- [[Freestyle Fellowship & Pharcyde routes]]
- [[Fugees as a group]]
- [[Busta Rhymes & Big Pun]]
- [[Hiplife, kwaito, Afro-trap & rap-afrobeats exchange]]
- [[Dance, graffiti, radio & organizing beyond tracks]]

## Guide examples

- [The Roots — What They Do](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/07-expansion-counterpublics.html#track-107)
- [Black Star — Definition](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/07-expansion-counterpublics.html#track-108)
- [dead prez — Hip-Hop](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/07-expansion-counterpublics.html#track-109)
- [Lauryn Hill — Lost Ones](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/07-expansion-counterpublics.html#track-110)
- [Missy Elliott — The Rain (Supa Dupa Fly)](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/07-expansion-counterpublics.html#track-111)

[[_Start Here|Return to atlas index]]
