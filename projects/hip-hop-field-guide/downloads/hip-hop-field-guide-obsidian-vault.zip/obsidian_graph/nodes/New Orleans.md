---
title: "New Orleans"
map-group: scene
node-id: scene-new-orleans
tags:
  - hip-hop-field-guide
  - map/scene
---

# New Orleans

Bounce dance practice and the distinct Cash Money and No Limit producer-business systems.

## Direct connections

- [[Regional systems]]
- [[Expansion & counterpublics]]
- [[South, mixtapes & producers]]
- [[Internet transition]]

## Guide examples

- [DJ Jimi feat. Juvenile — Bounce (For the Juvenile)](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/06-regional-systems.html#track-096)
- [DJ Jubilee — Do the Jubilee All](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/06-regional-systems.html#track-097)
- [Juvenile — Ha](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/07-expansion-counterpublics.html#track-122)
- [Master P featuring Fiend Mia X Mystikal and Silkk the Shocker — Make 'Em Say Uhh!](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/07-expansion-counterpublics.html#track-123)
- [Lil Wayne — Tha Mobb](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/08-south-mixtapes-producers.html#track-136)
- [Lil Wayne — A Milli](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/09-internet-transition.html#track-151)

[[_Start Here|Return to atlas index]]
