---
title: "Electro & machine funk"
map-group: production
node-id: prod-electro
tags:
  - hip-hop-field-guide
  - map/production
---

# Electro & machine funk

Drum-machine and synthesizer futurism, often connected to breaking and electronic-club exchange.

## Direct connections

- [[Recorded rap & electro]]
- [[New school]]
- [[South, mixtapes & producers]]
- [[Internet transition]]
- [[Fractured center]]

## Guide examples

- [Afrika Bambaataa and the Soulsonic Force — Planet Rock](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/03-recorded-rap.html#track-033)
- [Yellow Magic Orchestra — Rap Phenomena](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/03-recorded-rap.html#track-035)
- [Run-D.M.C. — It's Like That](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/03-recorded-rap.html#track-036)
- [Newtrament — London Bridge Is Falling Down](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/03-recorded-rap.html#track-038)
- [Schoolly D — P.S.K. What Does It Mean?](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/04-new-school.html#track-041)
- [M.I.A. — Galang](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/08-south-mixtapes-producers.html#track-145)
- [Dizzee Rascal — I Luv U](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/08-south-mixtapes-producers.html#track-146)

[[_Start Here|Return to atlas index]]
