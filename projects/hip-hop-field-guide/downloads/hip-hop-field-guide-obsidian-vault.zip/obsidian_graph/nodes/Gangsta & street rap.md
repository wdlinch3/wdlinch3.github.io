---
title: "Gangsta & street rap"
map-group: practice
node-id: practice-street
tags:
  - hip-hop-field-guide
  - map/practice
---

# Gangsta & street rap

A contested field of persona, reportage, crime narrative, fantasy, political observation, and market construction.

## Direct connections

- [[Before the name]]
- [[New school]]
- [[Plural golden ages]]
- [[Regional systems]]
- [[Expansion & counterpublics]]
- [[South, mixtapes & producers]]
- [[Internet transition]]
- [[Fractured center]]
- [[Platform era]]
- [[Unfinished present]]

## Guide examples

- [Lightnin' Rod — Sport](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/01-before-the-name.html#track-012)
- [Schoolly D — P.S.K. What Does It Mean?](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/04-new-school.html#track-041)
- [Hijack — Style Wars](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/04-new-school.html#track-056)
- [Kool G Rap & DJ Polo — Streets of New York](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/05-plural-golden-ages.html#track-065)
- [N.W.A — Straight Outta Compton](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/05-plural-golden-ages.html#track-066)
- [Ice-T — Colors](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/05-plural-golden-ages.html#track-067)
- [Cypress Hill — How I Could Just Kill a Man](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/05-plural-golden-ages.html#track-075)

[[_Start Here|Return to atlas index]]
