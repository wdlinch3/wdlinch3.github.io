---
title: "Flow & lyrical formalism"
map-group: practice
node-id: practice-flow
tags:
  - hip-hop-field-guide
  - map/practice
---

# Flow & lyrical formalism

Accent, rhyme, phrasing, breath, timbre, and the changing fit between language and beat.

## Direct connections

- [[Live culture]]
- [[Recorded rap & electro]]
- [[New school]]
- [[Plural golden ages]]
- [[Regional systems]]
- [[Expansion & counterpublics]]
- [[South, mixtapes & producers]]
- [[Internet transition]]
- [[Fractured center]]
- [[Platform era]]
- [[Unfinished present]]

## Guide examples

- [Grandmaster Flash and the Furious Four MCs — Live at the Audubon Ballroom — December 23 1978](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/02-live-culture.html#track-013)
- [Funky Four — Live at unknown location](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/02-live-culture.html#track-015)
- [DJ Hollywood — Live club routine](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/02-live-culture.html#track-019)
- [The Sugarhill Gang — Rapper's Delight](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/03-recorded-rap.html#track-021)
- [Spoonie Gee — Spoonin Rap](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/03-recorded-rap.html#track-025)
- [The Treacherous Three — The New Rap Language](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/03-recorded-rap.html#track-028)
- [Mean Machine — Disco Dream](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/03-recorded-rap.html#track-031)

[[_Start Here|Return to atlas index]]
