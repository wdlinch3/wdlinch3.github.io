---
title: "Singles & albums"
map-group: circulation
node-id: circ-record
tags:
  - hip-hop-field-guide
  - map/circulation
---

# Singles & albums

Commercial recording formats that preserve, transform, and market selected parts of a live culture.

## Direct connections

- [[Live culture]]
- [[Recorded rap & electro]]
- [[New school]]
- [[Plural golden ages]]
- [[Expansion & counterpublics]]
- [[Internet transition]]

## Guide examples

- [Grandmaster Flash and the Furious Four MCs — Live at the Audubon Ballroom — December 23 1978](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/02-live-culture.html#track-013)
- [Cold Crush Four and Disco Enforcers — Live at T-Connection](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/02-live-culture.html#track-018)
- [The Sugarhill Gang — Rapper's Delight](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/03-recorded-rap.html#track-021)
- [The Fatback Band featuring King Tim III — King Tim III (Personality Jock)](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/03-recorded-rap.html#track-022)
- [Brother D with Collective Effort — How We Gonna Make the Black Nation Rise?](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/03-recorded-rap.html#track-027)
- [Grandmaster Flash — The Adventures of Grandmaster Flash on the Wheels of Steel](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/03-recorded-rap.html#track-030)
- [Grandmaster Flash and the Furious Five — The Message](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/03-recorded-rap.html#track-032)

[[_Start Here|Return to atlas index]]
