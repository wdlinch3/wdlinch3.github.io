---
title: "Los Angeles & Compton"
map-group: scene
node-id: scene-la
tags:
  - hip-hop-field-guide
  - map/scene
---

# Los Angeles & Compton

West Coast electro, gangsta, alternative, and producer systems whose differences matter.

## Direct connections

- [[Before the name]]
- [[Plural golden ages]]
- [[Regional systems]]
- [[South, mixtapes & producers]]
- [[Internet transition]]
- [[Fractured center]]
- [[Platform era]]
- [[Unfinished present]]

## Guide examples

- [The Watts Prophets — Dem Niggers Ain't Playing](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/01-before-the-name.html#track-006)
- [N.W.A — Straight Outta Compton](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/05-plural-golden-ages.html#track-066)
- [Ice-T — Colors](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/05-plural-golden-ages.html#track-067)
- [DJ Quik — Tonite](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/05-plural-golden-ages.html#track-069)
- [Too $hort — The Ghetto](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/05-plural-golden-ages.html#track-070)
- [Yo-Yo featuring Ice Cube — You Can't Play with My Yo-Yo](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/05-plural-golden-ages.html#track-073)
- [Cypress Hill — How I Could Just Kill a Man](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/05-plural-golden-ages.html#track-075)

[[_Start Here|Return to atlas index]]
