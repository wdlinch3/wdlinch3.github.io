---
title: "Storytelling & reportage"
map-group: practice
node-id: practice-story
tags:
  - hip-hop-field-guide
  - map/practice
---

# Storytelling & reportage

Narrative techniques used for neighborhood report, crime story, comedy, mourning, autobiography, and political observation.

## Direct connections

- [[Before the name]]
- [[Recorded rap & electro]]
- [[New school]]
- [[Plural golden ages]]
- [[Regional systems]]
- [[Expansion & counterpublics]]
- [[South, mixtapes & producers]]
- [[Internet transition]]
- [[Fractured center]]
- [[Unfinished present]]

## Guide examples

- [Lightnin' Rod — Sport](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/01-before-the-name.html#track-012)
- [Grandmaster Flash and the Furious Five — The Message](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/03-recorded-rap.html#track-032)
- [MC Lyte — I Cram to Understand U (Sam)](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/04-new-school.html#track-049)
- [Boogie Down Productions — You Must Learn](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/05-plural-golden-ages.html#track-058)
- [Kool G Rap & DJ Polo — Streets of New York](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/05-plural-golden-ages.html#track-065)
- [Ice-T — Colors](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/05-plural-golden-ages.html#track-067)
- [Geto Boys — Mind Playing Tricks on Me](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/05-plural-golden-ages.html#track-068)

[[_Start Here|Return to atlas index]]
