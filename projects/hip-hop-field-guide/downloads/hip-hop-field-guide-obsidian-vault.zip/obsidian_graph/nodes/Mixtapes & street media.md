---
title: "Mixtapes & street media"
map-group: circulation
node-id: circ-mixtape
tags:
  - hip-hop-field-guide
  - map/circulation
---

# Mixtapes & street media

Informal and semi-formal distribution systems joining exclusives, freestyles, DJ authorship, and local reputation.

## Direct connections

- [[Regional systems]]
- [[Expansion & counterpublics]]
- [[South, mixtapes & producers]]
- [[Internet transition]]
- [[Fractured center]]
- [[Platform era]]
- [[Unfinished present]]

## Guide examples

- [DJ Screw and Screwed Up Click — June 27th Freestyle](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/06-regional-systems.html#track-095)
- [DMX — Ruff Ryders' Anthem](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/07-expansion-counterpublics.html#track-120)
- [Gucci Mane — Trap House](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/08-south-mixtapes-producers.html#track-135)
- [Lil Wayne — Tha Mobb](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/08-south-mixtapes-producers.html#track-136)
- [50 Cent — Many Men (Wish Death)](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/08-south-mixtapes-producers.html#track-139)
- [Lil Wayne — A Milli](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/09-internet-transition.html#track-151)
- [Nicki Minaj — Itty Bitty Piggy](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/09-internet-transition.html#track-157)

[[_Start Here|Return to atlas index]]
