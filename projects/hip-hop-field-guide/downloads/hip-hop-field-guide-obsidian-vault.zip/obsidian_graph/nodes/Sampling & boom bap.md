---
title: "Sampling & boom bap"
map-group: production
node-id: prod-sampling
tags:
  - hip-hop-field-guide
  - map/production
---

# Sampling & boom bap

Several lineages of chopped recordings and forceful programmed drums, not one universal golden-age beat.

## Direct connections

- [[Before the name]]
- [[New school]]
- [[Plural golden ages]]
- [[Regional systems]]
- [[Expansion & counterpublics]]
- [[South, mixtapes & producers]]
- [[Fractured center]]
- [[Platform era]]
- [[Unfinished present]]

## Guide examples

- [James Brown — Funky Drummer](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/01-before-the-name.html#track-005)
- [Eric B. & Rakim — Eric B. Is President](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/04-new-school.html#track-043)
- [Boogie Down Productions — South Bronx](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/04-new-school.html#track-044)
- [Ultramagnetic MC's — Ego Trippin'](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/04-new-school.html#track-046)
- [EPMD — It's My Thing](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/04-new-school.html#track-052)
- [Audio Two — Top Billin'](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/04-new-school.html#track-053)
- [De La Soul — Me Myself and I](https://wdlinch3.github.io/projects/hip-hop-field-guide/chapters/05-plural-golden-ages.html#track-060)

[[_Start Here|Return to atlas index]]
