---
title: Hip-Hop Field Guide Atlas
tags:
  - hip-hop-field-guide
  - map/index
---

# Hip-Hop Field Guide Atlas

Open Obsidian's **Graph view** to see the ordinary force-directed dot-and-line network. This vault is optional navigation: the Quarto guide and track manifest remain authoritative.

Obsidian's global graph can rearrange itself when notes are opened or filters change. The public web map uses fixed positions and is the better choice when preserving your place matters.

## Historical blocks

- [[Before the name]]
- [[Live culture]]
- [[Recorded rap & electro]]
- [[New school]]
- [[Plural golden ages]]
- [[Regional systems]]
- [[Expansion & counterpublics]]
- [[South, mixtapes & producers]]
- [[Internet transition]]
- [[Fractured center]]
- [[Platform era]]
- [[Unfinished present]]

## Scenes

- [[New York borough systems]]
- [[Philadelphia & New Jersey]]
- [[Los Angeles & Compton]]
- [[Bay Area]]
- [[Atlanta]]
- [[Houston]]
- [[Memphis]]
- [[New Orleans]]
- [[Midwest systems]]
- [[Florida]]
- [[United Kingdom]]
- [[France & francophone circuits]]
- [[Latin American & Caribbean circuits]]
- [[African scenes]]
- [[Asian & Oceanian scenes]]

## Production grammars

- [[DJ, breaks & turntablism]]
- [[Electro & machine funk]]
- [[Sampling & boom bap]]
- [[G-funk]]
- [[Bass, bounce & dance systems]]
- [[Chopped and screwed]]
- [[Trap lineages]]
- [[Drill migrations]]
- [[Melody & vocal processing]]
- [[Cloud, plugg & rage descendants]]
- [[Abstract, industrial & experimental]]
- [[Live bands & instruments]]

## MC and social practices

- [[Party, dance & crowd command]]
- [[Message & political rap]]
- [[Battle & braggadocio]]
- [[Storytelling & reportage]]
- [[Flow & lyrical formalism]]
- [[Gangsta & street rap]]
- [[Interiority, testimony & mourning]]
- [[Independent & counterpublic routes]]

## Circulation systems

- [[Parties, radio & tapes]]
- [[Singles & albums]]
- [[Independent labels & regional business]]
- [[Mixtapes & street media]]
- [[Blogs & direct internet circulation]]
- [[Streaming & viral platforms]]

## Routes beyond this edition

- [[Freestyle Fellowship & Pharcyde routes]]
- [[Fugees as a group]]
- [[Busta Rhymes & Big Pun]]
- [[Scarface solo route]]
- [[Dälek, clipping. & noise-rap branches]]
- [[Roc Marciano & minimalist revival]]
- [[Nipsey Hussle & modern West Coast independence]]
- [[Megan Thee Stallion & modern Houston women]]
- [[Hiplife, kwaito, Afro-trap & rap-afrobeats exchange]]
- [[Country rap & rural Southern hybrids]]
- [[Dance, graffiti, radio & organizing beyond tracks]]
