---
title: How to Open the EDM Dot-and-Line Graph
tags:
  - music/edm
  - listening-guide
status: optional-navigation
---

# How to Open the EDM Dot-and-Line Graph

The files in `obsidian_genre_graph/genres/` exist specifically so Obsidian's native Graph View can render genres as circular dots and their relationships as lines. They are a generated navigation layer; the canonical explanations remain in [[genre_atlas|EDM Genre Atlas]] and the Quarto field guide.

1. Click **Open graph view** in Obsidian's left ribbon (the icon made of three connected circles).
2. Click the **gear** in the graph's upper-right corner.
3. In **Filters → Search files**, enter exactly: `path:"obsidian_genre_graph/genres"`
4. Under **Display**, raise **Node size** and **Link thickness** if desired. Lower **Text fade threshold** if labels disappear too quickly.
5. Under **Forces**, adjust **Repel force** and **Link distance** to spread crowded regions apart.

Navigation: scroll or use `+` and `-` to zoom; drag the background to pan; hover over a dot to isolate its immediate connections; click a dot to open its genre note.

Status groups can be colored with these optional Graph View queries:

- `tag:#music/edm/status/represented`
- `tag:#music/edm/status/unrepresented`
- `tag:#music/edm/status/candidate`

Generated network: **179 genre notes and 184 directed relationships**.
