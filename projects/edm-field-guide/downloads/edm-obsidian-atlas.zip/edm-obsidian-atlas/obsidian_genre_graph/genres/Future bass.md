---
title: "Future bass"
pillar: 5
pillar-name: "5. Electro, hip-hop bass, and US city-club systems"
status: represented
tags:
  - music/edm/genre-graph
  - music/edm/pillar-5
  - music/edm/status/represented
---

# Future bass

**Atlas status:** represented in the current guide

**Pillar:** 5. Electro, hip-hop bass, and US city-club systems

## Broad inputs and antecedents

- [[obsidian_genre_graph/genres/Wonky – maximalist bass|Wonky / maximalist bass]] — exchange
- [[obsidian_genre_graph/genres/Festival trap|Festival trap]] — broad lineage or influence

## Context

See [[genre_atlas|EDM Genre Atlas]] for the qualified historical explanation and [[edm_field_guide|A Field Guide to Electronic Dance Music]] for the listening route.
