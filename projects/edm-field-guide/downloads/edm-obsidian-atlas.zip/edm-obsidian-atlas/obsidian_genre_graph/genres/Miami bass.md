---
title: "Miami bass"
pillar: 5
pillar-name: "5. Electro, hip-hop bass, and US city-club systems"
status: represented
tags:
  - music/edm/genre-graph
  - music/edm/pillar-5
  - music/edm/status/represented
---

# Miami bass

**Atlas status:** represented in the current guide

**Pillar:** 5. Electro, hip-hop bass, and US city-club systems

## Broad inputs and antecedents

- [[obsidian_genre_graph/genres/Electro – hip-hop|Electro / hip-hop]] — broad lineage or influence

## Routes onward

- [[obsidian_genre_graph/genres/Ghetto house|Ghetto house]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Funk carioca roots|Funk carioca roots]] — broad lineage or influence

## Context

See [[genre_atlas|EDM Genre Atlas]] for the qualified historical explanation and [[edm_field_guide|A Field Guide to Electronic Dance Music]] for the listening route.
