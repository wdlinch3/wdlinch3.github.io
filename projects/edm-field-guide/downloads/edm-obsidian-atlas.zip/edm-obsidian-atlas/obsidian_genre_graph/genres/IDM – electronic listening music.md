---
title: "IDM / electronic listening music"
pillar: 6
pillar-name: "6. Industrial dance and experimental electronic music"
status: represented
tags:
  - music/edm/genre-graph
  - music/edm/pillar-6
  - music/edm/status/represented
---

# IDM / electronic listening music

**Atlas status:** represented in the current guide

**Pillar:** 6. Industrial dance and experimental electronic music

## Broad inputs and antecedents

- [[obsidian_genre_graph/genres/Nine Inch Nails – industrial-rock boundary|Nine Inch Nails / industrial-rock boundary]] — remix exchange
- [[obsidian_genre_graph/genres/Detroit techno|Detroit techno]] — broad lineage or influence

## Routes onward

- [[obsidian_genre_graph/genres/Ambient techno|Ambient techno]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Downtempo|Downtempo]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Experimental – deconstructed club|Experimental / deconstructed club]] — broad lineage or influence

## Context

See [[genre_atlas|EDM Genre Atlas]] for the qualified historical explanation and [[edm_field_guide|A Field Guide to Electronic Dance Music]] for the listening route.
