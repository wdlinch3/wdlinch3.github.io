---
title: "Broken beat / bruk"
pillar: 3
pillar-name: "3. Breakbeat, jungle, drum & bass, and breaks"
status: unrepresented
tags:
  - music/edm/genre-graph
  - music/edm/pillar-3
  - music/edm/status/unrepresented
---

# Broken beat / bruk

**Atlas status:** important unrepresented neighbor

**Pillar:** 3. Breakbeat, jungle, drum & bass, and breaks

## Broad inputs and antecedents

- [[obsidian_genre_graph/genres/Jungle|Jungle]] — exchange
- [[obsidian_genre_graph/genres/South African – Afro house|South African / Afro house]] — exchange

## Context

See [[genre_atlas|EDM Genre Atlas]] for the qualified historical explanation and [[edm_field_guide|A Field Guide to Electronic Dance Music]] for the listening route.
