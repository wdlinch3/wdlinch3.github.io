---
title: "Experimental / deconstructed club"
pillar: 6
pillar-name: "6. Industrial dance and experimental electronic music"
status: represented
tags:
  - music/edm/genre-graph
  - music/edm/pillar-6
  - music/edm/status/represented
---

# Experimental / deconstructed club

**Atlas status:** represented in the current guide

**Pillar:** 6. Industrial dance and experimental electronic music

## Broad inputs and antecedents

- [[obsidian_genre_graph/genres/IDM – electronic listening music|IDM / electronic listening music]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Industrial techno – rhythmic noise|Industrial techno / rhythmic noise]] — broad lineage or influence

## Routes onward

- [[obsidian_genre_graph/genres/Post-club – diasporic percussive work|Post-club / diasporic percussive work]] — broad lineage or influence

## Context

See [[genre_atlas|EDM Genre Atlas]] for the qualified historical explanation and [[edm_field_guide|A Field Guide to Electronic Dance Music]] for the listening route.
