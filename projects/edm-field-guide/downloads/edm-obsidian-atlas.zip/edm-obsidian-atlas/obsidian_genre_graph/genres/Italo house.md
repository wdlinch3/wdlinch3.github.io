---
title: "Italo house"
pillar: 1
pillar-name: "1. Disco, house, US garage, and techno"
status: unrepresented
tags:
  - music/edm/genre-graph
  - music/edm/pillar-1
  - music/edm/status/unrepresented
---

# Italo house

**Atlas status:** important unrepresented neighbor

**Pillar:** 1. Disco, house, US garage, and techno

## Routes onward

- [[obsidian_genre_graph/genres/Chicago house|Chicago house]] — exchange

## Context

See [[genre_atlas|EDM Genre Atlas]] for the qualified historical explanation and [[edm_field_guide|A Field Guide to Electronic Dance Music]] for the listening route.
