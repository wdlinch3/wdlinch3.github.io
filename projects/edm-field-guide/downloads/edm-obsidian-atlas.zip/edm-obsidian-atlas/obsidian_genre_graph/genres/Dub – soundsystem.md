---
title: "Dub / soundsystem"
pillar: 8
pillar-name: "8. Caribbean and Latin electronic-dance routes"
status: represented
tags:
  - music/edm/genre-graph
  - music/edm/pillar-8
  - music/edm/status/represented
---

# Dub / soundsystem

**Atlas status:** represented in the current guide

**Pillar:** 8. Caribbean and Latin electronic-dance routes

## Routes onward

- [[obsidian_genre_graph/genres/Jungle|Jungle]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Dubstep|Dubstep]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Nine Inch Nails – industrial-rock boundary|Nine Inch Nails / industrial-rock boundary]] — studio exchange
- [[obsidian_genre_graph/genres/Digital dancehall|Digital dancehall]] — broad lineage or influence

## Context

See [[genre_atlas|EDM Genre Atlas]] for the qualified historical explanation and [[edm_field_guide|A Field Guide to Electronic Dance Music]] for the listening route.
