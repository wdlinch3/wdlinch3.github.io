---
title: "The Prodigy: rave-to-big-beat bridge"
pillar: 2
pillar-name: "2. Rave, hardcore, hard dance, and trance"
status: candidate
tags:
  - music/edm/genre-graph
  - music/edm/pillar-2
  - music/edm/status/candidate
---

# The Prodigy: rave-to-big-beat bridge

**Atlas status:** next-iteration bridge or boundary proposal

**Pillar:** 2. Rave, hardcore, hard dance, and trance

## Broad inputs and antecedents

- [[obsidian_genre_graph/genres/Breakbeat hardcore|Breakbeat hardcore]] — broad lineage or influence

## Routes onward

- [[obsidian_genre_graph/genres/Big beat|Big beat]] — broad lineage or influence

## Context

See [[genre_atlas|EDM Genre Atlas]] for the qualified historical explanation and [[edm_field_guide|A Field Guide to Electronic Dance Music]] for the listening route.
