---
title: "Shanghai experimental club"
pillar: 10
pillar-name: "10. SWANA, South Asian, East Asian, and Southeast Asian routes"
status: represented
tags:
  - music/edm/genre-graph
  - music/edm/pillar-10
  - music/edm/status/represented
---

# Shanghai experimental club

**Atlas status:** represented in the current guide

**Pillar:** 10. SWANA, South Asian, East Asian, and Southeast Asian routes

## Broad inputs and antecedents

- [[obsidian_genre_graph/genres/Chinese electronic-music networks|Chinese electronic-music networks]] — broad lineage or influence

## Context

See [[genre_atlas|EDM Genre Atlas]] for the qualified historical explanation and [[edm_field_guide|A Field Guide to Electronic Dance Music]] for the listening route.
