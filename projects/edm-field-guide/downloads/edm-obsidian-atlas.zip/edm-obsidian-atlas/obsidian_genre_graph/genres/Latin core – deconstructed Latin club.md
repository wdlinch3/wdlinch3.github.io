---
title: "Latin core / deconstructed Latin club"
pillar: 8
pillar-name: "8. Caribbean and Latin electronic-dance routes"
status: represented
tags:
  - music/edm/genre-graph
  - music/edm/pillar-8
  - music/edm/status/represented
---

# Latin core / deconstructed Latin club

**Atlas status:** represented in the current guide

**Pillar:** 8. Caribbean and Latin electronic-dance routes

## Broad inputs and antecedents

- [[obsidian_genre_graph/genres/Puerto Rican reggaetón|Puerto Rican reggaetón]] — exchange
- [[obsidian_genre_graph/genres/Funk carioca roots|Funk carioca roots]] — exchange
- [[obsidian_genre_graph/genres/Soca – bouyon – shatta|Soca / bouyon / shatta]] — exchange

## Context

See [[genre_atlas|EDM Genre Atlas]] for the qualified historical explanation and [[edm_field_guide|A Field Guide to Electronic Dance Music]] for the listening route.
