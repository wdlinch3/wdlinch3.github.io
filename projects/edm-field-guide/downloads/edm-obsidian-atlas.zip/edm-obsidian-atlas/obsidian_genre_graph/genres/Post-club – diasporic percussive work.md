---
title: "Post-club / diasporic percussive work"
pillar: 6
pillar-name: "6. Industrial dance and experimental electronic music"
status: represented
tags:
  - music/edm/genre-graph
  - music/edm/pillar-6
  - music/edm/status/represented
---

# Post-club / diasporic percussive work

**Atlas status:** represented in the current guide

**Pillar:** 6. Industrial dance and experimental electronic music

## Broad inputs and antecedents

- [[obsidian_genre_graph/genres/Experimental – deconstructed club|Experimental / deconstructed club]] — broad lineage or influence
- [[obsidian_genre_graph/genres/SWANA rhythmic knowledge|SWANA rhythmic knowledge]] — broad lineage or influence

## Context

See [[genre_atlas|EDM Genre Atlas]] for the qualified historical explanation and [[edm_field_guide|A Field Guide to Electronic Dance Music]] for the listening route.
