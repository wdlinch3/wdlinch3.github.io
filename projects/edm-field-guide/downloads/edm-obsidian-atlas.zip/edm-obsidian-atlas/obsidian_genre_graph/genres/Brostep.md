---
title: "Brostep"
pillar: 4
pillar-name: "4. UK garage, grime, dubstep, and UK bass"
status: represented
tags:
  - music/edm/genre-graph
  - music/edm/pillar-4
  - music/edm/status/represented
---

# Brostep

**Atlas status:** represented in the current guide

**Pillar:** 4. UK garage, grime, dubstep, and UK bass

## Broad inputs and antecedents

- [[obsidian_genre_graph/genres/Dubstep|Dubstep]] — broad lineage or influence

## Routes onward

- [[obsidian_genre_graph/genres/Riddim dubstep – trench|Riddim dubstep / trench]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Modern tearout|Modern tearout]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Festival-scale build, breakdown, and drop|Festival-scale build, breakdown, and drop]] — broad lineage or influence

## Context

See [[genre_atlas|EDM Genre Atlas]] for the qualified historical explanation and [[edm_field_guide|A Field Guide to Electronic Dance Music]] for the listening route.
