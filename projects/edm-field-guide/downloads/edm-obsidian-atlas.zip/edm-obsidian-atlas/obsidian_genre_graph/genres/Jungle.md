---
title: "Jungle"
pillar: 3
pillar-name: "3. Breakbeat, jungle, drum & bass, and breaks"
status: represented
tags:
  - music/edm/genre-graph
  - music/edm/pillar-3
  - music/edm/status/represented
---

# Jungle

**Atlas status:** represented in the current guide

**Pillar:** 3. Breakbeat, jungle, drum & bass, and breaks

## Broad inputs and antecedents

- [[obsidian_genre_graph/genres/Breakbeat hardcore|Breakbeat hardcore]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Dub – soundsystem|Dub / soundsystem]] — broad lineage or influence

## Routes onward

- [[obsidian_genre_graph/genres/Ragga jungle|Ragga jungle]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Dark jungle|Dark jungle]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Atmospheric jungle|Atmospheric jungle]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Jump-up jungle|Jump-up jungle]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Drum & bass|Drum & bass]] — broad lineage or influence
- [[obsidian_genre_graph/genres/New-jungle revival|New-jungle revival]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Broken beat – bruk|Broken beat / bruk]] — exchange
- [[obsidian_genre_graph/genres/UK garage|UK garage]] — exchange

## Context

See [[genre_atlas|EDM Genre Atlas]] for the qualified historical explanation and [[edm_field_guide|A Field Guide to Electronic Dance Music]] for the listening route.
