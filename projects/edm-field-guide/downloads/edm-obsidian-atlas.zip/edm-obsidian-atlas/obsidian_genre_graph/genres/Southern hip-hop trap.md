---
title: "Southern hip-hop trap"
pillar: 5
pillar-name: "5. Electro, hip-hop bass, and US city-club systems"
status: unrepresented
tags:
  - music/edm/genre-graph
  - music/edm/pillar-5
  - music/edm/status/unrepresented
---

# Southern hip-hop trap

**Atlas status:** important unrepresented neighbor

**Pillar:** 5. Electro, hip-hop bass, and US city-club systems

## Routes onward

- [[obsidian_genre_graph/genres/Festival trap|Festival trap]] — broad lineage or influence

## Context

See [[genre_atlas|EDM Genre Atlas]] for the qualified historical explanation and [[edm_field_guide|A Field Guide to Electronic Dance Music]] for the listening route.
