---
title: "2-step"
pillar: 4
pillar-name: "4. UK garage, grime, dubstep, and UK bass"
status: represented
tags:
  - music/edm/genre-graph
  - music/edm/pillar-4
  - music/edm/status/represented
---

# 2-step

**Atlas status:** represented in the current guide

**Pillar:** 4. UK garage, grime, dubstep, and UK bass

## Broad inputs and antecedents

- [[obsidian_genre_graph/genres/Speed garage|Speed garage]] — broad lineage or influence

## Routes onward

- [[obsidian_genre_graph/genres/Dark 2-step|Dark 2-step]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Grime – eski|Grime / eski]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Proto-dubstep|Proto-dubstep]] — broad lineage or influence

## Context

See [[genre_atlas|EDM Genre Atlas]] for the qualified historical explanation and [[edm_field_guide|A Field Guide to Electronic Dance Music]] for the listening route.
