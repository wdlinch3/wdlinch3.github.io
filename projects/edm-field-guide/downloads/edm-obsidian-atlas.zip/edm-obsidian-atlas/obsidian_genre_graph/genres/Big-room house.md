---
title: "Big-room house"
pillar: 7
pillar-name: "7. Festival EDM constellation"
status: represented
tags:
  - music/edm/genre-graph
  - music/edm/pillar-7
  - music/edm/status/represented
---

# Big-room house

**Atlas status:** represented in the current guide

**Pillar:** 7. Festival EDM constellation

## Broad inputs and antecedents

- [[obsidian_genre_graph/genres/Electro house|Electro house]] — broad lineage or influence

## Routes onward

- [[obsidian_genre_graph/genres/Festival-scale build, breakdown, and drop|Festival-scale build, breakdown, and drop]] — broad lineage or influence

## Context

See [[genre_atlas|EDM Genre Atlas]] for the qualified historical explanation and [[edm_field_guide|A Field Guide to Electronic Dance Music]] for the listening route.
