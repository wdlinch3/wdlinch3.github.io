---
title: "Early trance"
pillar: 2
pillar-name: "2. Rave, hardcore, hard dance, and trance"
status: represented
tags:
  - music/edm/genre-graph
  - music/edm/pillar-2
  - music/edm/status/represented
---

# Early trance

**Atlas status:** represented in the current guide

**Pillar:** 2. Rave, hardcore, hard dance, and trance

## Broad inputs and antecedents

- [[obsidian_genre_graph/genres/Detroit techno|Detroit techno]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Acid house|Acid house]] — broad lineage or influence

## Routes onward

- [[obsidian_genre_graph/genres/Progressive – acid trance|Progressive / acid trance]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Classic – uplifting – vocal trance|Classic / uplifting / vocal trance]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Hard trance – tech trance|Hard trance / tech trance]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Goa trance – psytrance|Goa trance / psytrance]] — broad lineage or influence

## Context

See [[genre_atlas|EDM Genre Atlas]] for the qualified historical explanation and [[edm_field_guide|A Field Guide to Electronic Dance Music]] for the listening route.
