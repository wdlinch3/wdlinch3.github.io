---
title: "Egyptian shaabi histories"
pillar: 10
pillar-name: "10. SWANA, South Asian, East Asian, and Southeast Asian routes"
status: represented
tags:
  - music/edm/genre-graph
  - music/edm/pillar-10
  - music/edm/status/represented
---

# Egyptian shaabi histories

**Atlas status:** represented in the current guide

**Pillar:** 10. SWANA, South Asian, East Asian, and Southeast Asian routes

## Routes onward

- [[obsidian_genre_graph/genres/Islam Chipsy & EEK live-electronic practice|Islam Chipsy & EEK live-electronic practice]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Mahraganat – electro-shaabi|Mahraganat / electro-shaabi]] — broad lineage or influence

## Context

See [[genre_atlas|EDM Genre Atlas]] for the qualified historical explanation and [[edm_field_guide|A Field Guide to Electronic Dance Music]] for the listening route.
