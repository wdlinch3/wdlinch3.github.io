---
title: "Drum & bass"
pillar: 3
pillar-name: "3. Breakbeat, jungle, drum & bass, and breaks"
status: represented
tags:
  - music/edm/genre-graph
  - music/edm/pillar-3
  - music/edm/status/represented
---

# Drum & bass

**Atlas status:** represented in the current guide

**Pillar:** 3. Breakbeat, jungle, drum & bass, and breaks

## Broad inputs and antecedents

- [[obsidian_genre_graph/genres/Jungle|Jungle]] — broad lineage or influence

## Routes onward

- [[obsidian_genre_graph/genres/Atmospheric D&B|Atmospheric D&B]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Jazzstep|Jazzstep]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Techstep|Techstep]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Liquid funk|Liquid funk]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Dancefloor D&B|Dancefloor D&B]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Jump-up D&B|Jump-up D&B]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Drumfunk|Drumfunk]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Halftime D&B|Halftime D&B]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Crossbreed|Crossbreed]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Sambass|Sambass]] — broad lineage or influence

## Context

See [[genre_atlas|EDM Genre Atlas]] for the qualified historical explanation and [[edm_field_guide|A Field Guide to Electronic Dance Music]] for the listening route.
