---
title: "UK funky"
pillar: 4
pillar-name: "4. UK garage, grime, dubstep, and UK bass"
status: represented
tags:
  - music/edm/genre-graph
  - music/edm/pillar-4
  - music/edm/status/represented
---

# UK funky

**Atlas status:** represented in the current guide

**Pillar:** 4. UK garage, grime, dubstep, and UK bass

## Broad inputs and antecedents

- [[obsidian_genre_graph/genres/UK garage|UK garage]] — exchange
- [[obsidian_genre_graph/genres/Grime – eski|Grime / eski]] — exchange

## Routes onward

- [[obsidian_genre_graph/genres/Hard drum – percussive club|Hard drum / percussive club]] — exchange

## Context

See [[genre_atlas|EDM Genre Atlas]] for the qualified historical explanation and [[edm_field_guide|A Field Guide to Electronic Dance Music]] for the listening route.
