---
title: "Detroit techno"
pillar: 1
pillar-name: "1. Disco, house, US garage, and techno"
status: represented
tags:
  - music/edm/genre-graph
  - music/edm/pillar-1
  - music/edm/status/represented
---

# Detroit techno

**Atlas status:** represented in the current guide

**Pillar:** 1. Disco, house, US garage, and techno

## Broad inputs and antecedents

- [[obsidian_genre_graph/genres/Electro – hip-hop|Electro / hip-hop]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Italo disco|Italo disco]] — exchange
- [[obsidian_genre_graph/genres/Chicago house|Chicago house]] — exchange

## Routes onward

- [[obsidian_genre_graph/genres/Minimal techno|Minimal techno]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Loop techno|Loop techno]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Dub techno|Dub techno]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Bleep techno|Bleep techno]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Acid techno|Acid techno]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Hard techno|Hard techno]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Birmingham – industrial techno|Birmingham / industrial techno]] — broad lineage or influence
- [[obsidian_genre_graph/genres/UK – European rave ecology|UK / European rave ecology]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Early trance|Early trance]] — broad lineage or influence
- [[obsidian_genre_graph/genres/IDM – electronic listening music|IDM / electronic listening music]] — broad lineage or influence

## Context

See [[genre_atlas|EDM Genre Atlas]] for the qualified historical explanation and [[edm_field_guide|A Field Guide to Electronic Dance Music]] for the listening route.
