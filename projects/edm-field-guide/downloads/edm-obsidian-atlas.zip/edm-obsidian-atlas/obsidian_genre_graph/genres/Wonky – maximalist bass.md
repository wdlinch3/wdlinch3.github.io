---
title: "Wonky / maximalist bass"
pillar: 4
pillar-name: "4. UK garage, grime, dubstep, and UK bass"
status: represented
tags:
  - music/edm/genre-graph
  - music/edm/pillar-4
  - music/edm/status/represented
---

# Wonky / maximalist bass

**Atlas status:** represented in the current guide

**Pillar:** 4. UK garage, grime, dubstep, and UK bass

## Broad inputs and antecedents

- [[obsidian_genre_graph/genres/Post-dubstep – future garage|Post-dubstep / future garage]] — exchange

## Routes onward

- [[obsidian_genre_graph/genres/Future bass|Future bass]] — exchange

## Context

See [[genre_atlas|EDM Genre Atlas]] for the qualified historical explanation and [[edm_field_guide|A Field Guide to Electronic Dance Music]] for the listening route.
