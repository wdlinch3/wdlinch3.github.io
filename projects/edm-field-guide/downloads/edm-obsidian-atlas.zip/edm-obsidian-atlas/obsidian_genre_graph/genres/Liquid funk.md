---
title: "Liquid funk"
pillar: 3
pillar-name: "3. Breakbeat, jungle, drum & bass, and breaks"
status: represented
tags:
  - music/edm/genre-graph
  - music/edm/pillar-3
  - music/edm/status/represented
---

# Liquid funk

**Atlas status:** represented in the current guide

**Pillar:** 3. Breakbeat, jungle, drum & bass, and breaks

## Broad inputs and antecedents

- [[obsidian_genre_graph/genres/Drum & bass|Drum & bass]] — broad lineage or influence

## Context

See [[genre_atlas|EDM Genre Atlas]] for the qualified historical explanation and [[edm_field_guide|A Field Guide to Electronic Dance Music]] for the listening route.
