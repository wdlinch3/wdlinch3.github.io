---
title: "Amapiano"
pillar: 9
pillar-name: "9. African and Afro-diasporic electronic-dance routes"
status: represented
tags:
  - music/edm/genre-graph
  - music/edm/pillar-9
  - music/edm/status/represented
---

# Amapiano

**Atlas status:** represented in the current guide

**Pillar:** 9. African and Afro-diasporic electronic-dance routes

## Broad inputs and antecedents

- [[obsidian_genre_graph/genres/South African house|South African house]] — broad lineage or influence
- [[obsidian_genre_graph/genres/South African – Afro house|South African / Afro house]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Bacardi – Pretoria house|Bacardi / Pretoria house]] — exchange
- [[obsidian_genre_graph/genres/Afrobeats – Afropop boundary|Afrobeats / Afropop boundary]] — exchange

## Context

See [[genre_atlas|EDM Genre Atlas]] for the qualified historical explanation and [[edm_field_guide|A Field Guide to Electronic Dance Music]] for the listening route.
