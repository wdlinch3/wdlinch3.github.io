---
title: "West African electronic popular-dance histories"
pillar: 9
pillar-name: "9. African and Afro-diasporic electronic-dance routes"
status: unrepresented
tags:
  - music/edm/genre-graph
  - music/edm/pillar-9
  - music/edm/status/unrepresented
---

# West African electronic popular-dance histories

**Atlas status:** important unrepresented neighbor

**Pillar:** 9. African and Afro-diasporic electronic-dance routes

## Routes onward

- [[obsidian_genre_graph/genres/Coupé-décalé|Coupé-décalé]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Azonto-era electronic dance-pop|Azonto-era electronic dance-pop]] — broad lineage or influence

## Context

See [[genre_atlas|EDM Genre Atlas]] for the qualified historical explanation and [[edm_field_guide|A Field Guide to Electronic Dance Music]] for the listening route.
