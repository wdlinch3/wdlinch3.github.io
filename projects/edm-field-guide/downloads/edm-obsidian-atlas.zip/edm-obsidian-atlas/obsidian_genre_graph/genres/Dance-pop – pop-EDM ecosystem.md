---
title: "Dance-pop / pop-EDM ecosystem"
pillar: 7
pillar-name: "7. Festival EDM constellation"
status: unrepresented
tags:
  - music/edm/genre-graph
  - music/edm/pillar-7
  - music/edm/status/unrepresented
---

# Dance-pop / pop-EDM ecosystem

**Atlas status:** important unrepresented neighbor

**Pillar:** 7. Festival EDM constellation

## Context

See [[genre_atlas|EDM Genre Atlas]] for the qualified historical explanation and [[edm_field_guide|A Field Guide to Electronic Dance Music]] for the listening route.
