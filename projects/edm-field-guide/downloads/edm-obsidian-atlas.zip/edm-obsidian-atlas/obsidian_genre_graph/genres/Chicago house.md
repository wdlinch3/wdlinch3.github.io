---
title: "Chicago house"
pillar: 1
pillar-name: "1. Disco, house, US garage, and techno"
status: represented
tags:
  - music/edm/genre-graph
  - music/edm/pillar-1
  - music/edm/status/represented
---

# Chicago house

**Atlas status:** represented in the current guide

**Pillar:** 1. Disco, house, US garage, and techno

## Broad inputs and antecedents

- [[obsidian_genre_graph/genres/Boogie – post-disco|Boogie / post-disco]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Italo house|Italo house]] — exchange

## Routes onward

- [[obsidian_genre_graph/genres/Jack track|Jack track]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Piano house|Piano house]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Deep house|Deep house]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Acid house|Acid house]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Vocal – gospel – soulful house|Vocal / gospel / soulful house]] — broad lineage or influence
- [[obsidian_genre_graph/genres/French touch – filter house|French touch / filter house]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Minimal – microhouse|Minimal / microhouse]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Progressive house|Progressive house]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Tech house|Tech house]] — broad lineage or influence
- [[obsidian_genre_graph/genres/South African – Afro house|South African / Afro house]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Detroit techno|Detroit techno]] — exchange
- [[obsidian_genre_graph/genres/Electro house|Electro house]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Festival progressive house|Festival progressive house]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Festival tech house|Festival tech house]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Future house|Future house]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Tropical house|Tropical house]] — broad lineage or influence

## Context

See [[genre_atlas|EDM Genre Atlas]] for the qualified historical explanation and [[edm_field_guide|A Field Guide to Electronic Dance Music]] for the listening route.
