---
title: "Funkot"
pillar: 10
pillar-name: "10. SWANA, South Asian, East Asian, and Southeast Asian routes"
status: unrepresented
tags:
  - music/edm/genre-graph
  - music/edm/pillar-10
  - music/edm/status/unrepresented
---

# Funkot

**Atlas status:** important unrepresented neighbor

**Pillar:** 10. SWANA, South Asian, East Asian, and Southeast Asian routes

## Context

See [[genre_atlas|EDM Genre Atlas]] for the qualified historical explanation and [[edm_field_guide|A Field Guide to Electronic Dance Music]] for the listening route.
