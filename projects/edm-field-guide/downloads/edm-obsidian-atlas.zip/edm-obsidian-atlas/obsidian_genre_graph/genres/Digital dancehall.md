---
title: "Digital dancehall"
pillar: 8
pillar-name: "8. Caribbean and Latin electronic-dance routes"
status: represented
tags:
  - music/edm/genre-graph
  - music/edm/pillar-8
  - music/edm/status/represented
---

# Digital dancehall

**Atlas status:** represented in the current guide

**Pillar:** 8. Caribbean and Latin electronic-dance routes

## Broad inputs and antecedents

- [[obsidian_genre_graph/genres/Dub – soundsystem|Dub / soundsystem]] — broad lineage or influence

## Routes onward

- [[obsidian_genre_graph/genres/Reggae en español|Reggae en español]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Puerto Rican reggaetón|Puerto Rican reggaetón]] — broad lineage or influence

## Context

See [[genre_atlas|EDM Genre Atlas]] for the qualified historical explanation and [[edm_field_guide|A Field Guide to Electronic Dance Music]] for the listening route.
