---
title: "Happy hardcore"
pillar: 2
pillar-name: "2. Rave, hardcore, hard dance, and trance"
status: represented
tags:
  - music/edm/genre-graph
  - music/edm/pillar-2
  - music/edm/status/represented
---

# Happy hardcore

**Atlas status:** represented in the current guide

**Pillar:** 2. Rave, hardcore, hard dance, and trance

## Broad inputs and antecedents

- [[obsidian_genre_graph/genres/Breakbeat hardcore|Breakbeat hardcore]] — broad lineage or influence

## Routes onward

- [[obsidian_genre_graph/genres/Later UK hardcore|Later UK hardcore]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Makina – bouncy techno – donk|Makina / bouncy techno / donk]] — broad lineage or influence

## Context

See [[genre_atlas|EDM Genre Atlas]] for the qualified historical explanation and [[edm_field_guide|A Field Guide to Electronic Dance Music]] for the listening route.
