---
title: "Free tekno / tribe / hardtek"
pillar: 2
pillar-name: "2. Rave, hardcore, hard dance, and trance"
status: unrepresented
tags:
  - music/edm/genre-graph
  - music/edm/pillar-2
  - music/edm/status/unrepresented
---

# Free tekno / tribe / hardtek

**Atlas status:** important unrepresented neighbor

**Pillar:** 2. Rave, hardcore, hard dance, and trance

## Broad inputs and antecedents

- [[obsidian_genre_graph/genres/Hardcore techno|Hardcore techno]] — broad lineage or influence

## Context

See [[genre_atlas|EDM Genre Atlas]] for the qualified historical explanation and [[edm_field_guide|A Field Guide to Electronic Dance Music]] for the listening route.
