---
title: "US garage / garage house"
pillar: 1
pillar-name: "1. Disco, house, US garage, and techno"
status: represented
tags:
  - music/edm/genre-graph
  - music/edm/pillar-1
  - music/edm/status/represented
---

# US garage / garage house

**Atlas status:** represented in the current guide

**Pillar:** 1. Disco, house, US garage, and techno

## Broad inputs and antecedents

- [[obsidian_genre_graph/genres/Boogie – post-disco|Boogie / post-disco]] — broad lineage or influence

## Routes onward

- [[obsidian_genre_graph/genres/Vocal – gospel – soulful house|Vocal / gospel / soulful house]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Cut-up garage house|Cut-up garage house]] — broad lineage or influence
- [[obsidian_genre_graph/genres/UK garage|UK garage]] — broad lineage or influence

## Context

See [[genre_atlas|EDM Genre Atlas]] for the qualified historical explanation and [[edm_field_guide|A Field Guide to Electronic Dance Music]] for the listening route.
