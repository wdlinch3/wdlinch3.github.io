---
title: "UK garage"
pillar: 4
pillar-name: "4. UK garage, grime, dubstep, and UK bass"
status: represented
tags:
  - music/edm/genre-graph
  - music/edm/pillar-4
  - music/edm/status/represented
---

# UK garage

**Atlas status:** represented in the current guide

**Pillar:** 4. UK garage, grime, dubstep, and UK bass

## Broad inputs and antecedents

- [[obsidian_genre_graph/genres/US garage – garage house|US garage / garage house]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Jungle|Jungle]] — exchange

## Routes onward

- [[obsidian_genre_graph/genres/Speed garage|Speed garage]] — broad lineage or influence
- [[obsidian_genre_graph/genres/UK funky|UK funky]] — exchange

## Context

See [[genre_atlas|EDM Genre Atlas]] for the qualified historical explanation and [[edm_field_guide|A Field Guide to Electronic Dance Music]] for the listening route.
