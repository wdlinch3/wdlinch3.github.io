---
title: "Birmingham / industrial techno"
pillar: 1
pillar-name: "1. Disco, house, US garage, and techno"
status: unrepresented
tags:
  - music/edm/genre-graph
  - music/edm/pillar-1
  - music/edm/status/unrepresented
---

# Birmingham / industrial techno

**Atlas status:** important unrepresented neighbor

**Pillar:** 1. Disco, house, US garage, and techno

## Broad inputs and antecedents

- [[obsidian_genre_graph/genres/Detroit techno|Detroit techno]] — broad lineage or influence

## Context

See [[genre_atlas|EDM Genre Atlas]] for the qualified historical explanation and [[edm_field_guide|A Field Guide to Electronic Dance Music]] for the listening route.
