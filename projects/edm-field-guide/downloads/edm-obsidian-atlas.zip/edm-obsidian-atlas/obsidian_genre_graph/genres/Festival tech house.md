---
title: "Festival tech house"
pillar: 7
pillar-name: "7. Festival EDM constellation"
status: represented
tags:
  - music/edm/genre-graph
  - music/edm/pillar-7
  - music/edm/status/represented
---

# Festival tech house

**Atlas status:** represented in the current guide

**Pillar:** 7. Festival EDM constellation

## Broad inputs and antecedents

- [[obsidian_genre_graph/genres/Chicago house|Chicago house]] — broad lineage or influence

## Context

See [[genre_atlas|EDM Genre Atlas]] for the qualified historical explanation and [[edm_field_guide|A Field Guide to Electronic Dance Music]] for the listening route.
