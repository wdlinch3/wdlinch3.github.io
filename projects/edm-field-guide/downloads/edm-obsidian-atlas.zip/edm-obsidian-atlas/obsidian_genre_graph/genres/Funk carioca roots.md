---
title: "Funk carioca roots"
pillar: 8
pillar-name: "8. Caribbean and Latin electronic-dance routes"
status: represented
tags:
  - music/edm/genre-graph
  - music/edm/pillar-8
  - music/edm/status/represented
---

# Funk carioca roots

**Atlas status:** represented in the current guide

**Pillar:** 8. Caribbean and Latin electronic-dance routes

## Broad inputs and antecedents

- [[obsidian_genre_graph/genres/Miami bass|Miami bass]] — broad lineage or influence

## Routes onward

- [[obsidian_genre_graph/genres/Tamborzão-era funk carioca|Tamborzão-era funk carioca]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Latin core – deconstructed Latin club|Latin core / deconstructed Latin club]] — exchange

## Context

See [[genre_atlas|EDM Genre Atlas]] for the qualified historical explanation and [[edm_field_guide|A Field Guide to Electronic Dance Music]] for the listening route.
