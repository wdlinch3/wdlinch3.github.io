---
title: "Funk breaks / hip-hop sampling"
pillar: 3
pillar-name: "3. Breakbeat, jungle, drum & bass, and breaks"
status: represented
tags:
  - music/edm/genre-graph
  - music/edm/pillar-3
  - music/edm/status/represented
---

# Funk breaks / hip-hop sampling

**Atlas status:** represented in the current guide

**Pillar:** 3. Breakbeat, jungle, drum & bass, and breaks

## Routes onward

- [[obsidian_genre_graph/genres/Breakbeat method|Breakbeat method]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Baltimore club|Baltimore club]] — broad lineage or influence
- [[obsidian_genre_graph/genres/New Orleans bounce|New Orleans bounce]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Trip-hop boundary|Trip-hop boundary]] — broad lineage or influence

## Context

See [[genre_atlas|EDM Genre Atlas]] for the qualified historical explanation and [[edm_field_guide|A Field Guide to Electronic Dance Music]] for the listening route.
