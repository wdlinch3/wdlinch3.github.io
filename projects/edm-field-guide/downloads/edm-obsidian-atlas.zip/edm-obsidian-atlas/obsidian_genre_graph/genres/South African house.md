---
title: "South African house"
pillar: 9
pillar-name: "9. African and Afro-diasporic electronic-dance routes"
status: represented
tags:
  - music/edm/genre-graph
  - music/edm/pillar-9
  - music/edm/status/represented
---

# South African house

**Atlas status:** represented in the current guide

**Pillar:** 9. African and Afro-diasporic electronic-dance routes

## Routes onward

- [[obsidian_genre_graph/genres/Kwaito|Kwaito]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Gqom|Gqom]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Amapiano|Amapiano]] — broad lineage or influence

## Context

See [[genre_atlas|EDM Genre Atlas]] for the qualified historical explanation and [[edm_field_guide|A Field Guide to Electronic Dance Music]] for the listening route.
