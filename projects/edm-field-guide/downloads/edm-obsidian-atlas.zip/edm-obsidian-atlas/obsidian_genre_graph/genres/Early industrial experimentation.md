---
title: "Early industrial experimentation"
pillar: 6
pillar-name: "6. Industrial dance and experimental electronic music"
status: unrepresented
tags:
  - music/edm/genre-graph
  - music/edm/pillar-6
  - music/edm/status/unrepresented
---

# Early industrial experimentation

**Atlas status:** important unrepresented neighbor

**Pillar:** 6. Industrial dance and experimental electronic music

## Routes onward

- [[obsidian_genre_graph/genres/Electronic body music|Electronic body music]] — broad lineage or influence

## Context

See [[genre_atlas|EDM Genre Atlas]] for the qualified historical explanation and [[edm_field_guide|A Field Guide to Electronic Dance Music]] for the listening route.
