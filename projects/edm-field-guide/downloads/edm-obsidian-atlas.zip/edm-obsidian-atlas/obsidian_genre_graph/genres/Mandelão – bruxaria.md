---
title: "Mandelão / bruxaria"
pillar: 8
pillar-name: "8. Caribbean and Latin electronic-dance routes"
status: unrepresented
tags:
  - music/edm/genre-graph
  - music/edm/pillar-8
  - music/edm/status/unrepresented
---

# Mandelão / bruxaria

**Atlas status:** important unrepresented neighbor

**Pillar:** 8. Caribbean and Latin electronic-dance routes

## Broad inputs and antecedents

- [[obsidian_genre_graph/genres/Tamborzão-era funk carioca|Tamborzão-era funk carioca]] — broad lineage or influence

## Context

See [[genre_atlas|EDM Genre Atlas]] for the qualified historical explanation and [[edm_field_guide|A Field Guide to Electronic Dance Music]] for the listening route.
