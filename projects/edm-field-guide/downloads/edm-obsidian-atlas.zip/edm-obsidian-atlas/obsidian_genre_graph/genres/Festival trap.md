---
title: "Festival trap"
pillar: 5
pillar-name: "5. Electro, hip-hop bass, and US city-club systems"
status: represented
tags:
  - music/edm/genre-graph
  - music/edm/pillar-5
  - music/edm/status/represented
---

# Festival trap

**Atlas status:** represented in the current guide

**Pillar:** 5. Electro, hip-hop bass, and US city-club systems

## Broad inputs and antecedents

- [[obsidian_genre_graph/genres/Southern hip-hop trap|Southern hip-hop trap]] — broad lineage or influence

## Routes onward

- [[obsidian_genre_graph/genres/Midtempo bass|Midtempo bass]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Future bass|Future bass]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Festival-scale build, breakdown, and drop|Festival-scale build, breakdown, and drop]] — broad lineage or influence

## Context

See [[genre_atlas|EDM Genre Atlas]] for the qualified historical explanation and [[edm_field_guide|A Field Guide to Electronic Dance Music]] for the listening route.
