---
title: "Industrial techno / rhythmic noise"
pillar: 6
pillar-name: "6. Industrial dance and experimental electronic music"
status: unrepresented
tags:
  - music/edm/genre-graph
  - music/edm/pillar-6
  - music/edm/status/unrepresented
---

# Industrial techno / rhythmic noise

**Atlas status:** important unrepresented neighbor

**Pillar:** 6. Industrial dance and experimental electronic music

## Broad inputs and antecedents

- [[obsidian_genre_graph/genres/Electronic body music|Electronic body music]] — broad lineage or influence

## Routes onward

- [[obsidian_genre_graph/genres/Experimental – deconstructed club|Experimental / deconstructed club]] — broad lineage or influence

## Context

See [[genre_atlas|EDM Genre Atlas]] for the qualified historical explanation and [[edm_field_guide|A Field Guide to Electronic Dance Music]] for the listening route.
