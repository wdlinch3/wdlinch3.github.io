---
title: "M-Beat feat. General Levy — Incredible"
pillar: 3
pillar-name: "3. Breakbeat, jungle, drum & bass, and breaks"
status: candidate
tags:
  - music/edm/genre-graph
  - music/edm/pillar-3
  - music/edm/status/candidate
---

# M-Beat feat. General Levy — Incredible

**Atlas status:** next-iteration bridge or boundary proposal

**Pillar:** 3. Breakbeat, jungle, drum & bass, and breaks

## Broad inputs and antecedents

- [[obsidian_genre_graph/genres/Ragga jungle|Ragga jungle]] — broad lineage or influence

## Context

See [[genre_atlas|EDM Genre Atlas]] for the qualified historical explanation and [[edm_field_guide|A Field Guide to Electronic Dance Music]] for the listening route.
