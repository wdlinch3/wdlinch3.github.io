---
title: "Bacardi / Pretoria house"
pillar: 9
pillar-name: "9. African and Afro-diasporic electronic-dance routes"
status: represented
tags:
  - music/edm/genre-graph
  - music/edm/pillar-9
  - music/edm/status/represented
---

# Bacardi / Pretoria house

**Atlas status:** represented in the current guide

**Pillar:** 9. African and Afro-diasporic electronic-dance routes

## Broad inputs and antecedents

- [[obsidian_genre_graph/genres/Kwaito|Kwaito]] — broad lineage or influence

## Routes onward

- [[obsidian_genre_graph/genres/Amapiano|Amapiano]] — exchange

## Context

See [[genre_atlas|EDM Genre Atlas]] for the qualified historical explanation and [[edm_field_guide|A Field Guide to Electronic Dance Music]] for the listening route.
