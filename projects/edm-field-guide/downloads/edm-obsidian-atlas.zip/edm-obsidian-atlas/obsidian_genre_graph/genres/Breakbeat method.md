---
title: "Breakbeat method"
pillar: 3
pillar-name: "3. Breakbeat, jungle, drum & bass, and breaks"
status: represented
tags:
  - music/edm/genre-graph
  - music/edm/pillar-3
  - music/edm/status/represented
---

# Breakbeat method

**Atlas status:** represented in the current guide

**Pillar:** 3. Breakbeat, jungle, drum & bass, and breaks

## Broad inputs and antecedents

- [[obsidian_genre_graph/genres/Funk breaks – hip-hop sampling|Funk breaks / hip-hop sampling]] — broad lineage or influence

## Routes onward

- [[obsidian_genre_graph/genres/Breakbeat hardcore|Breakbeat hardcore]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Big beat|Big beat]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Nu-skool breaks|Nu-skool breaks]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Florida breaks|Florida breaks]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Drill'n'bass|Drill'n'bass]] — broad lineage or influence

## Context

See [[genre_atlas|EDM Genre Atlas]] for the qualified historical explanation and [[edm_field_guide|A Field Guide to Electronic Dance Music]] for the listening route.
