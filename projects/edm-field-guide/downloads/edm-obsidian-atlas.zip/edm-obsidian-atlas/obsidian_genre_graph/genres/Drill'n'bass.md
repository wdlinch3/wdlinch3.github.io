---
title: "Drill'n'bass"
pillar: 6
pillar-name: "6. Industrial dance and experimental electronic music"
status: represented
tags:
  - music/edm/genre-graph
  - music/edm/pillar-6
  - music/edm/status/represented
---

# Drill'n'bass

**Atlas status:** represented in the current guide

**Pillar:** 6. Industrial dance and experimental electronic music

## Broad inputs and antecedents

- [[obsidian_genre_graph/genres/Breakbeat method|Breakbeat method]] — broad lineage or influence

## Routes onward

- [[obsidian_genre_graph/genres/Breakcore|Breakcore]] — broad lineage or influence

## Context

See [[genre_atlas|EDM Genre Atlas]] for the qualified historical explanation and [[edm_field_guide|A Field Guide to Electronic Dance Music]] for the listening route.
