---
title: "Tarraxo / tarraxinha"
pillar: 9
pillar-name: "9. African and Afro-diasporic electronic-dance routes"
status: unrepresented
tags:
  - music/edm/genre-graph
  - music/edm/pillar-9
  - music/edm/status/unrepresented
---

# Tarraxo / tarraxinha

**Atlas status:** important unrepresented neighbor

**Pillar:** 9. African and Afro-diasporic electronic-dance routes

## Routes onward

- [[obsidian_genre_graph/genres/Lisbon batida|Lisbon batida]] — exchange

## Context

See [[genre_atlas|EDM Genre Atlas]] for the qualified historical explanation and [[edm_field_guide|A Field Guide to Electronic Dance Music]] for the listening route.
