---
title: "Breakbeat hardcore"
pillar: 2
pillar-name: "2. Rave, hardcore, hard dance, and trance"
status: represented
tags:
  - music/edm/genre-graph
  - music/edm/pillar-2
  - music/edm/status/represented
---

# Breakbeat hardcore

**Atlas status:** represented in the current guide

**Pillar:** 2. Rave, hardcore, hard dance, and trance

## Broad inputs and antecedents

- [[obsidian_genre_graph/genres/UK – European rave ecology|UK / European rave ecology]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Breakbeat method|Breakbeat method]] — broad lineage or influence

## Routes onward

- [[obsidian_genre_graph/genres/Happy hardcore|Happy hardcore]] — broad lineage or influence
- [[obsidian_genre_graph/genres/The Prodigy— rave-to-big-beat bridge|The Prodigy: rave-to-big-beat bridge]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Jungle|Jungle]] — broad lineage or influence

## Context

See [[genre_atlas|EDM Genre Atlas]] for the qualified historical explanation and [[edm_field_guide|A Field Guide to Electronic Dance Music]] for the listening route.
