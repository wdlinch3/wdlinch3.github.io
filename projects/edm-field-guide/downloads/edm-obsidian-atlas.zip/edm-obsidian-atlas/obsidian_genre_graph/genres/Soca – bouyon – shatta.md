---
title: "Soca / bouyon / shatta"
pillar: 8
pillar-name: "8. Caribbean and Latin electronic-dance routes"
status: unrepresented
tags:
  - music/edm/genre-graph
  - music/edm/pillar-8
  - music/edm/status/unrepresented
---

# Soca / bouyon / shatta

**Atlas status:** important unrepresented neighbor

**Pillar:** 8. Caribbean and Latin electronic-dance routes

## Routes onward

- [[obsidian_genre_graph/genres/Latin core – deconstructed Latin club|Latin core / deconstructed Latin club]] — exchange

## Context

See [[genre_atlas|EDM Genre Atlas]] for the qualified historical explanation and [[edm_field_guide|A Field Guide to Electronic Dance Music]] for the listening route.
