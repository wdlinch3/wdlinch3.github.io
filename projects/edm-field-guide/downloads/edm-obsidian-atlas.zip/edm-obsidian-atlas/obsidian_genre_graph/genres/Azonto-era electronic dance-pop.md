---
title: "Azonto-era electronic dance-pop"
pillar: 9
pillar-name: "9. African and Afro-diasporic electronic-dance routes"
status: unrepresented
tags:
  - music/edm/genre-graph
  - music/edm/pillar-9
  - music/edm/status/unrepresented
---

# Azonto-era electronic dance-pop

**Atlas status:** important unrepresented neighbor

**Pillar:** 9. African and Afro-diasporic electronic-dance routes

## Broad inputs and antecedents

- [[obsidian_genre_graph/genres/West African electronic popular-dance histories|West African electronic popular-dance histories]] — broad lineage or influence

## Context

See [[genre_atlas|EDM Genre Atlas]] for the qualified historical explanation and [[edm_field_guide|A Field Guide to Electronic Dance Music]] for the listening route.
