---
title: "Electro / hip-hop"
pillar: 5
pillar-name: "5. Electro, hip-hop bass, and US city-club systems"
status: represented
tags:
  - music/edm/genre-graph
  - music/edm/pillar-5
  - music/edm/status/represented
---

# Electro / hip-hop

**Atlas status:** represented in the current guide

**Pillar:** 5. Electro, hip-hop bass, and US city-club systems

## Routes onward

- [[obsidian_genre_graph/genres/Detroit techno|Detroit techno]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Miami bass|Miami bass]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Freestyle|Freestyle]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Detroit electro|Detroit electro]] — broad lineage or influence

## Context

See [[genre_atlas|EDM Genre Atlas]] for the qualified historical explanation and [[edm_field_guide|A Field Guide to Electronic Dance Music]] for the listening route.
