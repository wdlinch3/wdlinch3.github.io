---
title: "Boogie / post-disco"
pillar: 1
pillar-name: "1. Disco, house, US garage, and techno"
status: represented
tags:
  - music/edm/genre-graph
  - music/edm/pillar-1
  - music/edm/status/represented
---

# Boogie / post-disco

**Atlas status:** represented in the current guide

**Pillar:** 1. Disco, house, US garage, and techno

## Broad inputs and antecedents

- [[obsidian_genre_graph/genres/Disco – electronic disco|Disco / electronic disco]] — broad lineage or influence

## Routes onward

- [[obsidian_genre_graph/genres/Chicago house|Chicago house]] — broad lineage or influence
- [[obsidian_genre_graph/genres/US garage – garage house|US garage / garage house]] — broad lineage or influence

## Context

See [[genre_atlas|EDM Genre Atlas]] for the qualified historical explanation and [[edm_field_guide|A Field Guide to Electronic Dance Music]] for the listening route.
