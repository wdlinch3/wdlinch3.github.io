---
title: "Nine Inch Nails / industrial-rock boundary"
pillar: 6
pillar-name: "6. Industrial dance and experimental electronic music"
status: candidate
tags:
  - music/edm/genre-graph
  - music/edm/pillar-6
  - music/edm/status/candidate
---

# Nine Inch Nails / industrial-rock boundary

**Atlas status:** next-iteration bridge or boundary proposal

**Pillar:** 6. Industrial dance and experimental electronic music

## Broad inputs and antecedents

- [[obsidian_genre_graph/genres/Electronic body music|Electronic body music]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Dub – soundsystem|Dub / soundsystem]] — studio exchange

## Routes onward

- [[obsidian_genre_graph/genres/IDM – electronic listening music|IDM / electronic listening music]] — remix exchange

## Context

See [[genre_atlas|EDM Genre Atlas]] for the qualified historical explanation and [[edm_field_guide|A Field Guide to Electronic Dance Music]] for the listening route.
