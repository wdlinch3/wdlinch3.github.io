---
title: "Juke"
pillar: 5
pillar-name: "5. Electro, hip-hop bass, and US city-club systems"
status: unrepresented
tags:
  - music/edm/genre-graph
  - music/edm/pillar-5
  - music/edm/status/unrepresented
---

# Juke

**Atlas status:** important unrepresented neighbor

**Pillar:** 5. Electro, hip-hop bass, and US city-club systems

## Broad inputs and antecedents

- [[obsidian_genre_graph/genres/Ghetto house|Ghetto house]] — broad lineage or influence

## Routes onward

- [[obsidian_genre_graph/genres/Footwork|Footwork]] — broad lineage or influence

## Context

See [[genre_atlas|EDM Genre Atlas]] for the qualified historical explanation and [[edm_field_guide|A Field Guide to Electronic Dance Music]] for the listening route.
