---
title: "Progressive / acid trance"
pillar: 2
pillar-name: "2. Rave, hardcore, hard dance, and trance"
status: represented
tags:
  - music/edm/genre-graph
  - music/edm/pillar-2
  - music/edm/status/represented
---

# Progressive / acid trance

**Atlas status:** represented in the current guide

**Pillar:** 2. Rave, hardcore, hard dance, and trance

## Broad inputs and antecedents

- [[obsidian_genre_graph/genres/Early trance|Early trance]] — broad lineage or influence

## Routes onward

- [[obsidian_genre_graph/genres/Festival progressive house|Festival progressive house]] — exchange

## Context

See [[genre_atlas|EDM Genre Atlas]] for the qualified historical explanation and [[edm_field_guide|A Field Guide to Electronic Dance Music]] for the listening route.
