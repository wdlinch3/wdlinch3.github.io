---
title: "SWANA rhythmic knowledge"
pillar: 10
pillar-name: "10. SWANA, South Asian, East Asian, and Southeast Asian routes"
status: represented
tags:
  - music/edm/genre-graph
  - music/edm/pillar-10
  - music/edm/status/represented
---

# SWANA rhythmic knowledge

**Atlas status:** represented in the current guide

**Pillar:** 10. SWANA, South Asian, East Asian, and Southeast Asian routes

## Routes onward

- [[obsidian_genre_graph/genres/Hard drum – percussive club|Hard drum / percussive club]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Post-club – diasporic percussive work|Post-club / diasporic percussive work]] — broad lineage or influence

## Context

See [[genre_atlas|EDM Genre Atlas]] for the qualified historical explanation and [[edm_field_guide|A Field Guide to Electronic Dance Music]] for the listening route.
