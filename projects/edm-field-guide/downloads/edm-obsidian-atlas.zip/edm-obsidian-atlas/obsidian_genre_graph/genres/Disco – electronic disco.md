---
title: "Disco / electronic disco"
pillar: 1
pillar-name: "1. Disco, house, US garage, and techno"
status: represented
tags:
  - music/edm/genre-graph
  - music/edm/pillar-1
  - music/edm/status/represented
---

# Disco / electronic disco

**Atlas status:** represented in the current guide

**Pillar:** 1. Disco, house, US garage, and techno

## Routes onward

- [[obsidian_genre_graph/genres/Boogie – post-disco|Boogie / post-disco]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Hi-NRG|Hi-NRG]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Italo disco|Italo disco]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Balearic beat|Balearic beat]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Ballroom – vogue beats|Ballroom / vogue beats]] — broad lineage or influence

## Context

See [[genre_atlas|EDM Genre Atlas]] for the qualified historical explanation and [[edm_field_guide|A Field Guide to Electronic Dance Music]] for the listening route.
