---
title: "Puerto Rican reggaetón"
pillar: 8
pillar-name: "8. Caribbean and Latin electronic-dance routes"
status: represented
tags:
  - music/edm/genre-graph
  - music/edm/pillar-8
  - music/edm/status/represented
---

# Puerto Rican reggaetón

**Atlas status:** represented in the current guide

**Pillar:** 8. Caribbean and Latin electronic-dance routes

## Broad inputs and antecedents

- [[obsidian_genre_graph/genres/Digital dancehall|Digital dancehall]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Reggae en español|Reggae en español]] — broad lineage or influence

## Routes onward

- [[obsidian_genre_graph/genres/Dominican dembow as genre|Dominican dembow as genre]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Neoperreo – queer Latin club|Neoperreo / queer Latin club]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Moombahton|Moombahton]] — broad lineage or influence
- [[obsidian_genre_graph/genres/Latin core – deconstructed Latin club|Latin core / deconstructed Latin club]] — exchange

## Context

See [[genre_atlas|EDM Genre Atlas]] for the qualified historical explanation and [[edm_field_guide|A Field Guide to Electronic Dance Music]] for the listening route.
