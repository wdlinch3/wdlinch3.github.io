---
title: "Footwork"
pillar: 5
pillar-name: "5. Electro, hip-hop bass, and US city-club systems"
status: represented
tags:
  - music/edm/genre-graph
  - music/edm/pillar-5
  - music/edm/status/represented
---

# Footwork

**Atlas status:** represented in the current guide

**Pillar:** 5. Electro, hip-hop bass, and US city-club systems

## Broad inputs and antecedents

- [[obsidian_genre_graph/genres/Juke|Juke]] — broad lineage or influence

## Routes onward

- [[obsidian_genre_graph/genres/Post-footwork abstraction|Post-footwork abstraction]] — broad lineage or influence

## Context

See [[genre_atlas|EDM Genre Atlas]] for the qualified historical explanation and [[edm_field_guide|A Field Guide to Electronic Dance Music]] for the listening route.
