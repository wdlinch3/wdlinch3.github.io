---
title: EDM Genre Atlas
aliases:
  - Electronic Dance Music Genre Map
tags:
  - music/edm
  - listening-guide
status: optional-navigation
canonical-guide: "edm_field_guide.qmd"
---

# EDM Genre Atlas

This is the Obsidian-compatible map for *A Field Guide to Electronic Dance Music*. The canonical narrative remains [the Quarto field guide](edm_field_guide.md), and [the track manifest](edm_playlist.csv) remains authoritative for the current 158-track order. This atlas is deliberately larger than the playlist: it shows represented genres, important unrepresented neighbors, and a few proposed bridge or boundary cases.

> **Looking for the familiar circular dot-and-line graph?** Open [[obsidian_genre_graph/START HERE|How to Open the EDM Dot-and-Line Graph]] and follow its short Graph View instructions. Open [[EDM Genre Network.canvas|EDM Genre Network]] when you prefer a deliberately arranged Canvas with rectangular cards. The diagrams farther down this note are smaller pillar-by-pillar views with accompanying explanation.

No electronic-dance taxonomy is complete or universally agreed. The arrows below mean broad historical transmission, branching, or sustained influence; they do not mean that one genre mechanically produced another. Dotted arrows indicate especially strong exchange or recombination. Cities, clubs, dances, technologies, migrations, and audiences often matter more than the family-tree metaphor can show.

## Legend

- **Green, solid node:** directly represented in the 158-track curriculum.
- **Gray, dashed node:** important context without a dedicated current selection.
- **Gold node:** proposed bridge or boundary case for a future iteration.
- **Solid arrow:** a useful first-pass lineage.
- **Dotted arrow:** exchange, overlap, or recombination rather than simple descent.

## Three easily confused terms

| Term | What kind of label is it? | Rhythmic center of gravity | Best beginner distinction |
|---|---|---|---|
| **Rave** | First a party culture and event ecology; also an umbrella for music built around it | May use a straight four-on-the-floor kick, breakbeats, or both | Ask what kind of gathering and collective intensity the music organizes; “rave” alone does not specify one drum grammar |
| **Techno** | A genre family originating in Detroit and subsequently transformed in many cities | Usually a steady four-on-the-floor pulse, machine-funk repetition, and gradual timbral or textural change | Follow the invariant pulse and notice how small changes become formally large |
| **Breakbeat** | Both a rhythmic method and a loose family of genres | Broken or syncopated drum patterns, often built from sampled or reconstructed funk breaks rather than a kick on every quarter note | Follow the internal kick–snare pattern; the bar has a shaped groove rather than one evenly reinforced downbeat grid |

These labels therefore occupy different taxonomic levels. A rave can feature techno, breakbeat hardcore, trance, or several of them in different rooms. Techno can be played at a rave. Breakbeat can describe the rhythmic engine inside hardcore, jungle, drum & bass, big beat, breaks, or other styles.

## Whole-field overview

```mermaid
flowchart TB
  DISCO["Disco, boogie, queer club practice"] --> HOUSE["House and US garage"]
  MACHINE["Electro, machine funk, synth music"] --> TECHNO["Techno"]
  INDUSTRIAL["Industrial and EBM"] --> RAVE["Rave, hardcore, hard dance"]
  HOUSE --> RAVE
  TECHNO --> RAVE
  HIPHOP["Hip-hop, funk breaks, 808 bass"] --> BREAKS["Breakbeat, jungle, drum & bass"]
  RAVE --> BREAKS
  JAMAICA["Soundsystem, dub, dancehall"] --> BREAKS
  HOUSE --> UKBASS["UK garage, grime, dubstep, bass"]
  BREAKS --> UKBASS
  JAMAICA --> UKBASS
  HIPHOP --> CITY["US bass and city-club forms"]
  HOUSE --> CITY
  JAMAICA --> LATIN["Caribbean and Latin electronic-dance routes"]
  HIPHOP --> LATIN
  GLOBAL["African, SWANA, Asian, and diasporic dance histories"] --> REGIONAL["Regional electronic-club systems"]
  HOUSE -.->|exchange| REGIONAL
  UKBASS -.->|exchange| REGIONAL
  HOUSE --> FESTIVAL["Festival EDM constellation"]
  RAVE --> FESTIVAL
  UKBASS --> FESTIVAL
  BREAKS --> FESTIVAL
  INDUSTRIAL -.-> EXPERIMENTAL["Industrial, IDM, breakcore, post-club"]
  BREAKS -.-> EXPERIMENTAL

  classDef represented fill:#d1e7dd,stroke:#198754,color:#111;
  class DISCO,MACHINE,INDUSTRIAL,HIPHOP,JAMAICA,GLOBAL,HOUSE,TECHNO,RAVE,BREAKS,UKBASS,CITY,LATIN,REGIONAL,FESTIVAL,EXPERIMENTAL represented;
```

## Pillar 1: disco, house, US garage, and techno

```mermaid
flowchart LR
  DISCO["Disco / electronic disco"] --> POST["Boogie / post-disco"]
  DISCO --> HINRG["Hi-NRG"]
  DISCO --> ITALO["Italo disco"]
  DISCO --> BALEARIC["Balearic beat"]:::unrepresented
  POST --> CHI["Chicago house"]
  POST --> USG["US garage / garage house"]
  CHI --> JACK["Jack track"]
  CHI --> PIANO["Piano house"]
  CHI --> DEEP["Deep house"]
  CHI --> ACID["Acid house"]
  CHI --> VOCAL["Vocal / gospel / soulful house"]
  USG --> VOCAL
  USG --> CUTUP["Cut-up garage house"]
  CHI --> FILTER["French touch / filter house"]
  CHI --> MICRO["Minimal / microhouse"]
  CHI --> PROGH["Progressive house"]
  CHI --> TECHH["Tech house"]
  CHI --> AFROH["South African / Afro house"]
  DEEP -.-> AFROH
  AFROH --> AMAPIANO["Amapiano"]
  MACHINE["Electro / machine funk"] --> DET["Detroit techno"]
  DET --> MIN["Minimal techno"]
  DET --> LOOP["Loop techno"]
  DET --> DUBT["Dub techno"]
  DET --> BLEEP["Bleep techno"]
  DET --> ACIDT["Acid techno"]
  DET --> HARDT["Hard techno"]
  DET --> BIRM["Birmingham / industrial techno"]:::unrepresented
  HARDT --> SCHRANZ["Schranz"]:::unrepresented
  CHI -.->|exchange| DET
  ITALO -.->|exchange| DET
  ITALOH["Italo house"]:::unrepresented -.-> CHI

  classDef represented fill:#d1e7dd,stroke:#198754,color:#111;
  classDef unrepresented fill:#f8f9fa,stroke:#6c757d,stroke-dasharray:5 5,color:#111;
  class DISCO,POST,HINRG,ITALO,CHI,USG,JACK,PIANO,DEEP,ACID,VOCAL,CUTUP,FILTER,MICRO,PROGH,TECHH,AFROH,AMAPIANO,MACHINE,DET,MIN,LOOP,DUBT,BLEEP,ACIDT,HARDT represented;
```

## Pillar 2: rave, hardcore, hard dance, and trance

```mermaid
flowchart LR
  ACID["Acid house"] --> RAVE["UK / European rave ecology"]
  TECHNO["Techno"] --> RAVE
  NEWBEAT["New beat"] --> RAVE
  EBM["EBM"] --> NEWBEAT
  RAVE --> BHC["Breakbeat hardcore"]
  RAVE --> HCT["Hardcore techno"]
  RAVE --> EURO["Eurodance / hip-house crossover"]
  BHC --> HAPPY["Happy hardcore"]
  HCT --> GABBER["Gabber"]
  GABBER --> FRENCH["Frenchcore"]
  GABBER --> HARDSTYLE["Hardstyle"]
  HCT --> FREE["Free tekno / tribe / hardtek"]:::unrepresented
  HAPPY --> UKHC["Later UK hardcore"]:::unrepresented
  HAPPY --> MAKINA["Makina / bouncy techno / donk"]:::unrepresented
  TECHNO --> EARLYTR["Early trance"]
  ACID --> EARLYTR
  EARLYTR --> PROGTR["Progressive / acid trance"]
  EARLYTR --> UPLIFT["Classic / uplifting / vocal trance"]
  EARLYTR --> HARDTR["Hard trance / tech trance"]:::unrepresented
  EARLYTR --> GOA["Goa trance"]
  GOA --> PSY["Psytrance"]
  PSY --> DARKPSY["Darkpsy"]
  PSY --> FULLON["Full-on / progressive psy"]:::unrepresented
  PRODIGY["The Prodigy: rave-to-big-beat bridge"]:::candidate
  BHC -.-> PRODIGY
  PRODIGY -.-> BIGBEAT["Big beat"]

  classDef represented fill:#d1e7dd,stroke:#198754,color:#111;
  classDef unrepresented fill:#f8f9fa,stroke:#6c757d,stroke-dasharray:5 5,color:#111;
  classDef candidate fill:#fff3cd,stroke:#d39e00,color:#111;
  class ACID,TECHNO,NEWBEAT,EBM,RAVE,BHC,HCT,EURO,HAPPY,GABBER,FRENCH,HARDSTYLE,EARLYTR,PROGTR,UPLIFT,GOA,PSY,DARKPSY,BIGBEAT represented;
```

## Pillar 3: breakbeat, jungle, drum & bass, and breaks

```mermaid
flowchart LR
  FUNK["Funk breaks / hip-hop sampling"] --> BREAKBEAT["Breakbeat method"]
  RAVE["Rave"] --> BHC["Breakbeat hardcore"]
  BREAKBEAT --> BHC
  DUB["Dub / soundsystem / dancehall"] --> JUNGLE["Jungle"]
  BHC --> JUNGLE
  JUNGLE --> RAGGA["Ragga jungle"]
  JUNGLE --> DARK["Dark jungle"]
  JUNGLE --> ATMJ["Atmospheric jungle"]
  JUNGLE --> JUMPJ["Jump-up jungle"]
  JUNGLE --> DNB["Drum & bass"]
  DNB --> ATM["Atmospheric D&B"]
  DNB --> JAZZ["Jazzstep"]
  DNB --> TECHSTEP["Techstep"]
  TECHSTEP --> NEURO["Neurofunk"]
  DNB --> LIQUID["Liquid funk"]
  DNB --> JUMPUP["Jump-up D&B"]
  JUMPUP --> FOGHORN["Foghorn-era jump-up tendency"]
  DNB --> DANCEFLOOR["Dancefloor D&B"]
  DNB --> DRUMFUNK["Drumfunk"]:::unrepresented
  DNB --> HALFTIME["Halftime D&B"]:::unrepresented
  DNB --> CROSSBREED["Crossbreed"]:::unrepresented
  DNB --> SAMBASS["Sambass"]:::unrepresented
  JUNGLE --> REVIVAL["New-jungle revival"]
  BREAKBEAT --> BIGBEAT["Big beat"]
  BREAKBEAT --> NUSKOOL["Nu-skool breaks"]
  BREAKBEAT --> FLORIDA["Florida breaks"]:::unrepresented
  HOUSE["House / jazz-funk"] -.-> BRUK["Broken beat / bruk"]:::unrepresented
  JUNGLE -.-> BRUK
  INCREDIBLE["M-Beat feat. General Levy — Incredible"]:::candidate
  RAGGA -.-> INCREDIBLE

  classDef represented fill:#d1e7dd,stroke:#198754,color:#111;
  classDef unrepresented fill:#f8f9fa,stroke:#6c757d,stroke-dasharray:5 5,color:#111;
  classDef candidate fill:#fff3cd,stroke:#d39e00,color:#111;
  class FUNK,BREAKBEAT,RAVE,BHC,DUB,JUNGLE,RAGGA,DARK,ATMJ,JUMPJ,DNB,ATM,JAZZ,TECHSTEP,NEURO,LIQUID,JUMPUP,FOGHORN,DANCEFLOOR,REVIVAL,BIGBEAT,NUSKOOL,HOUSE represented;
```

## Pillar 4: US garage, UK garage, grime, dubstep, and UK bass

```mermaid
flowchart LR
  USG["US garage / garage house"] --> UKG["UK garage"]
  JUNGLE["Jungle / soundsystem bass"] -.-> UKG
  UKG --> SPEED["Speed garage"]
  SPEED --> TWOSTEP["2-step"]
  TWOSTEP --> DARK2["Dark 2-step"]
  SPEED --> BASSLINE["Bassline / 4x4"]
  TWOSTEP --> GRIME["Grime / eski"]
  TWOSTEP --> PROTODUB["Proto-dubstep"]
  DUB["Dub / dancehall"] --> DUBSTEP["Dubstep"]
  PROTODUB --> DUBSTEP
  DUBSTEP --> ROOTS["Roots / deep dubstep"]
  DUBSTEP --> BROSTEP["Brostep"]
  DUBSTEP --> POSTDUB["Post-dubstep / future garage"]
  BROSTEP --> RIDDIM["Riddim dubstep / trench"]
  BROSTEP --> TEAROUT["Modern tearout"]
  ROOTS --> DEEP140["Contemporary deep 140 visibility"]
  UKG -.-> UKFUNKY["UK funky"]
  GRIME -.-> UKFUNKY
  UKFUNKY -.-> HARDDRUM["Hard drum / percussive club"]
  POSTDUB -.-> WONKY["Wonky / maximalist bass"]
  WONKY -.-> FUTUREBASS["Future-bass route"]

  classDef represented fill:#d1e7dd,stroke:#198754,color:#111;
  class USG,UKG,JUNGLE,SPEED,TWOSTEP,DARK2,BASSLINE,GRIME,PROTODUB,DUB,DUBSTEP,ROOTS,BROSTEP,POSTDUB,RIDDIM,TEAROUT,DEEP140,UKFUNKY,HARDDRUM,WONKY,FUTUREBASS represented;
```

## Pillar 5: electro, hip-hop bass, and US city-club systems

```mermaid
flowchart LR
  ELECTRO["Electro / hip-hop"] --> MIAMI["Miami bass"]
  ELECTRO --> FREESTYLE["Freestyle"]
  ELECTRO --> DETELECTRO["Detroit electro"]
  MIAMI --> GHETTOHOUSE["Ghetto house"]:::unrepresented
  DETELECTRO --> GHETTOTECH["Ghettotech"]
  GHETTOHOUSE --> JUKE["Juke"]:::unrepresented
  JUKE --> FOOTWORK["Footwork"]
  HIPHOP["Hip-hop break loops and MC practice"] --> BALT["Baltimore club"]
  BALT --> JERSEY["Jersey club"]
  HIPHOP --> BOUNCE["New Orleans bounce"]
  DISCO["Disco / queer and trans club practice"] --> BALLROOM["Ballroom / vogue beats"]
  HIPHOP -.-> BALLROOM
  TRAP["Southern hip-hop trap"]:::unrepresented --> FESTTRAP["Festival trap"]
  FESTTRAP --> MIDTEMPO["Midtempo bass"]
  FESTTRAP -.-> FUTUREBASS["Future bass"]

  classDef represented fill:#d1e7dd,stroke:#198754,color:#111;
  classDef unrepresented fill:#f8f9fa,stroke:#6c757d,stroke-dasharray:5 5,color:#111;
  class ELECTRO,MIAMI,FREESTYLE,DETELECTRO,GHETTOTECH,FOOTWORK,HIPHOP,BALT,JERSEY,BOUNCE,DISCO,BALLROOM,FESTTRAP,MIDTEMPO,FUTUREBASS represented;
```

## Pillar 6: industrial dance, electronic rock, and experimental club

```mermaid
flowchart LR
  INDUSTRIAL["Early industrial experimentation"]:::unrepresented --> EBM["Electronic body music"]
  EBM --> NEWBEAT["New beat"]
  EBM --> ELECTROCLASH["Electroclash"]
  EBM --> INDUSTRIALTECH["Industrial techno / rhythmic noise"]:::unrepresented
  EBM --> NIN["Nine Inch Nails / industrial-rock boundary"]:::candidate
  NIN -.->|remix and studio exchange| APHEX["IDM / Aphex Twin route"]
  DUB["Dub studio practice"] -.-> NIN
  TECHNO["Techno / ambient techno"] --> IDM["IDM / electronic listening music"]
  BREAKS["Breakbeat"] --> DRILL["Drill'n'bass"]
  DRILL --> BREAKCORE["Breakcore"]
  HIPHOP["Hip-hop / soul / dub production"] --> TRIPHOP["Trip-hop boundary"]
  IDM --> DOWNTEMPO["Downtempo"]
  IDM -.-> EXPCLUB["Experimental / deconstructed club"]
  INDUSTRIALTECH -.-> EXPCLUB
  EXPCLUB --> POSTCLUB["Post-club / diasporic percussive work"]

  classDef represented fill:#d1e7dd,stroke:#198754,color:#111;
  classDef unrepresented fill:#f8f9fa,stroke:#6c757d,stroke-dasharray:5 5,color:#111;
  classDef candidate fill:#fff3cd,stroke:#d39e00,color:#111;
  class EBM,NEWBEAT,ELECTROCLASH,APHEX,DUB,TECHNO,IDM,BREAKS,DRILL,BREAKCORE,HIPHOP,TRIPHOP,DOWNTEMPO,EXPCLUB,POSTCLUB represented;
```

## Pillar 7: festival EDM constellation

```mermaid
flowchart LR
  HOUSE["House"] --> ELECTROH["Electro house"]
  HOUSE --> PROGH["Festival progressive house"]
  HOUSE --> TECHH["Festival tech house"]
  ELECTROH --> BIGROOM["Big-room house"]
  ELECTROH --> COMPLEXTRO["Complextro"]
  HOUSE --> FUTUREH["Future house"]
  HOUSE --> TROPICAL["Tropical house"]
  TRANCE["Trance"] -.-> PROGH
  DUBSTEP["Dubstep"] --> BROSTEP["Brostep"]
  HIPHOPTRAP["Hip-hop trap"]:::unrepresented --> FESTTRAP["Festival trap"]
  FESTTRAP --> FUTUREBASS["Future bass"]
  DANCEPOP["Dance-pop / pop-EDM ecosystem"]:::unrepresented -.-> PROGH
  DANCEPOP -.-> TROPICAL
  BIGBEAT["Big beat / electronic-rock crossover"] --> FESTIVALFORM["Festival-scale build, breakdown, and drop"]
  PROGH --> FESTIVALFORM
  BIGROOM --> FESTIVALFORM
  BROSTEP --> FESTIVALFORM
  FESTTRAP --> FESTIVALFORM

  classDef represented fill:#d1e7dd,stroke:#198754,color:#111;
  classDef unrepresented fill:#f8f9fa,stroke:#6c757d,stroke-dasharray:5 5,color:#111;
  class HOUSE,ELECTROH,PROGH,TECHH,BIGROOM,COMPLEXTRO,FUTUREH,TROPICAL,TRANCE,DUBSTEP,BROSTEP,FESTTRAP,FUTUREBASS,BIGBEAT,FESTIVALFORM represented;
```

## Pillar 8: Caribbean and Latin electronic-dance routes

```mermaid
flowchart LR
  DUB["Dub / soundsystem"] --> DDH["Digital dancehall"]
  DDH --> REGESP["Reggae en español"]
  REGESP --> REGGAETON["Puerto Rican reggaetón"]
  DDH --> REGGAETON
  REGGAETON --> DEMBOW["Dominican dembow as genre"]:::unrepresented
  REGGAETON --> NEOPERREO["Neoperreo / queer Latin club"]
  REGGAETON --> MOOMBAH["Moombahton"]
  MIAMI["Miami bass / electro"] --> FUNKROOT["Funk carioca roots"]
  FUNKROOT --> TAMBOR["Tamborzão-era funk carioca"]
  TAMBOR --> MANDELAO["Mandelão / bruxaria developments"]:::unrepresented
  CUMBIA["Cumbia histories"]:::unrepresented --> DIGCUMBIA["Digital cumbia"]
  CUMBIA --> TRIBAL["Tribal guarachero"]
  TRIBAL -.-> GUARACHA["Colombian EDM guaracha"]:::unrepresented
  REGGAETON -.-> LATINCORE["Latin core / deconstructed Latin club"]
  FUNKROOT -.-> LATINCORE
  SOCA["Soca, bouyon, shatta and related Caribbean dance-pop"]:::unrepresented -.-> LATINCORE

  classDef represented fill:#d1e7dd,stroke:#198754,color:#111;
  classDef unrepresented fill:#f8f9fa,stroke:#6c757d,stroke-dasharray:5 5,color:#111;
  class DUB,DDH,REGESP,REGGAETON,NEOPERREO,MOOMBAH,MIAMI,FUNKROOT,TAMBOR,DIGCUMBIA,TRIBAL,LATINCORE represented;
```

## Pillar 9: African and Afro-diasporic electronic-dance routes

```mermaid
flowchart LR
  SAHOUSE["South African house"] --> KWAITO["Kwaito"]:::unrepresented
  KWAITO --> BACARDI["Bacardi / Pretoria house"]
  SAHOUSE --> GQOM["Gqom"]
  SAHOUSE --> AMAPIANO["Amapiano"]
  BACARDI -.-> AMAPIANO
  ANGOLA["Angolan urban dance histories"]:::unrepresented --> KUDURO["Kuduro"]
  KUDURO --> BATIDA["Lisbon batida"]
  TARRAXO["Tarraxo / tarraxinha"]:::unrepresented -.-> BATIDA
  SHANGAAN["Shangaan electro"]
  TANZANIA["Tanzanian popular and electronic dance histories"]:::unrepresented --> SINGELI["Singeli"]
  WEST["West African electronic popular-dance histories"]:::unrepresented --> COUPE["Coupé-décalé"]:::unrepresented
  WEST --> AZONTO["Azonto-era electronic dance-pop"]:::unrepresented
  AFROBEATS["Afrobeats / Afropop boundary"]:::unrepresented -.-> AMAPIANO
  KENYA["Kenyan global-club routes"]
  KUDURO -.-> GLOBAL["Global bass exchange"]
  GQOM -.-> GLOBAL
  SINGELI -.-> GLOBAL

  classDef represented fill:#d1e7dd,stroke:#198754,color:#111;
  classDef unrepresented fill:#f8f9fa,stroke:#6c757d,stroke-dasharray:5 5,color:#111;
  class SAHOUSE,BACARDI,GQOM,AMAPIANO,KUDURO,BATIDA,SHANGAAN,SINGELI,KENYA,GLOBAL represented;
```

## Pillar 10: SWANA, South Asian, East Asian, and Southeast Asian routes

```mermaid
flowchart LR
  SHAABI["Egyptian shaabi and wedding-performance histories"] --> CHIPSY["Islam Chipsy & EEK's neighboring live-electronic practice"]
  SHAABI --> MAHRAGANAT["Mahraganat / electro-shaabi"]:::unrepresented
  DABKE["Levantine dabke traditions"]:::unrepresented --> EDABKE["Electronic dabke"]:::unrepresented
  SWANA["SWANA rhythmic knowledge"] --> HARDDRUM["Hard drum / percussive club"]
  SWANA --> POSTCLUB["Diasporic / post-club practices"]
  GOA["Goa party ecology"] --> GOATRANCE["Goa trance / psytrance"]
  SOUTHASIA["South Asian popular and diasporic dance histories"]:::unrepresented --> ASIANUG["Asian Underground / desi bass"]:::unrepresented
  YMO["Japanese technopop"] --> JCORE["J-core / Japanese hardcore networks"]:::unrepresented
  INDONESIA["Indonesian popular-dance histories"]:::unrepresented --> FUNKOT["Funkot"]:::unrepresented
  VIETNAM["Vietnamese electronic-dance networks"]:::unrepresented --> VINAHOUSE["Vinahouse"]:::unrepresented
  PHILIPPINES["Visayan popular-dance ecology"]:::unrepresented --> BUDOTS["Budots"]
  CHINA["Chinese electronic-music networks"]:::unrepresented --> SHANGHAI["Shanghai experimental club"]

  classDef represented fill:#d1e7dd,stroke:#198754,color:#111;
  classDef unrepresented fill:#f8f9fa,stroke:#6c757d,stroke-dasharray:5 5,color:#111;
  class SHAABI,CHIPSY,SWANA,HARDDRUM,POSTCLUB,GOA,GOATRANCE,YMO,BUDOTS,SHANGHAI represented;
```

## Important unrepresented or proposed nodes

This is a survey backlog rather than an instruction to enlarge the playlist automatically. Some rows identify genuine coverage pressure; others would deepen an already represented family.

| Node | Why it matters | Nearest current route | Present status |
|---|---|---|---|
| **The Prodigy** | Makes the transition from breakbeat hardcore and rave into big beat and electronic-rock spectacle unusually audible | 4hero / SL2 → Chemical Brothers / Fatboy Slim | Proposed bridge; likely next-iteration entry |
| **Nine Inch Nails / industrial rock** | Connects EBM, dub-informed studio construction, remix deconstruction, machine rhythm, and alternative-rock performance | Nitzer Ebb → electroclash / Aphex Twin | Proposed boundary comparison rather than an EDM pillar representative |
| **M-Beat feat. General Levy — “Incredible”** | Personal memory anchor and canonical ragga-jungle crossover companion to “Original Nuttah” | SL2 → “Original Nuttah” → DJ Zinc | Proposed companion; exact mix question remains |
| **Balearic beat and Italo house** | Important Mediterranean and European routes between eclectic DJ culture, house, and later chill or progressive languages | Italo disco / ambient house / early house | Unrepresented |
| **Birmingham or industrial techno; schranz** | Prevents contemporary “hard techno” from standing in for several older severe techno traditions | Detroit/minimal/dub techno → contemporary hard techno | Unrepresented |
| **Free tekno, tribe, and hardtek** | Represents free-party and teknival infrastructure outside the commercial hard-dance story | Hardcore techno / gabber | Unrepresented |
| **Hard trance, later UK hardcore, makina, and donk** | Fills gaps between trance, happy hardcore, regional hard dance, and populist club culture | Early/uplifting trance; happy hardcore; hardstyle | Unrepresented |
| **Broken beat / bruk and Florida breaks** | Expands “breakbeat” beyond rave-to-jungle and big beat; broken beat also carries jazz-funk and West London history | UK funky / nu-skool breaks / jungle | Unrepresented |
| **Drumfunk, halftime D&B, crossbreed, and sambass** | Shows additional ways drum & bass can prioritize break detail, spaciousness, hardcore fusion, or Brazilian musical exchange | Atmospheric, techstep, neurofunk, liquid, jump-up D&B | Unrepresented refinements |
| **Ghetto house and juke as explicit stages** | Makes the Chicago route into footwork more legible rather than jumping directly to RP Boo | Chicago house / Miami bass → footwork | Unrepresented ancestry |
| **Dominican dembow** | The guide distinguishes the genre name from the reggaetón drum cell but has no central Dominican specimen | Dancehall → reggae en español → reggaetón / moombahton | Important explicit gap |
| **Mandelão/bruxaria and Colombian guaracha** | Extends the Latin route beyond the guide's earlier funk-carioca and tribal-guarachero moments | Funk carioca / tribal guarachero / Latin core | Unrepresented contemporary developments |
| **Kwaito** | Major South African predecessor and parallel context for later house-derived local forms | South African house → Bacardi / amapiano | Important explicit gap |
| **Coupé-décalé, azonto, and Afrobeats/Afropop boundary** | Broadens African electronic popular-dance context without pretending all of it is club-format EDM | Kuduro / gqom / amapiano / Kenyan global club | Scope-edge gap requiring careful framing |
| **Mahraganat and electronic dabke** | Prevents the SWANA route from being represented only by a neighboring live practice and diasporic post-club work | Islam Chipsy & EEK / DJ Plead / Deena Abdelwahed | Important explicit gap |
| **Asian Underground / desi bass** | Adds a South Asian diasporic route between breakbeats, bass music, bhangra, and electronic production | Goa/psytrance / UK bass / trip-hop boundary | Important explicit gap |
| **Funkot, Vinahouse, and J-core** | Makes East and Southeast Asian commercial or hardcore electronic-dance networks visible beside budots and experimental club | YMO / budots / Shanghai experimental club | Unrepresented; needs careful scene-specific research |
| **Soca, bouyon, and shatta** | Broadens Caribbean electronic dance beyond Jamaican ancestry and Spanish-language routes | Dancehall / reggaetón / Latin core | Scope-edge gap |

## Historical route through the current guide

| Era | Working question | Main tracks |
|---|---|---:|
| I. 1970–1983 | Which studio, soundsystem, disco, and machine practices supplied the toolkit? | 8 |
| II. 1983–1988 | How did local Chicago, Detroit, Miami, and New York/New Jersey scenes make distinct genres? | 13 |
| III. 1988–1992 | What changed when acid house and techno became a rave ecology? | 14 |
| IV. 1992–1995 | How did ambient, minimal, trance, Eurodance, jungle, and hard approaches become legible? | 14 |
| V. 1995–1999 | How did mature scenes split into sharper rhythmic and production branches? | 13 |
| VI. 1998–2004 | How did garage, grime, dubstep, liquid/techstep D&B, trance, and electroclash recombine post-rave materials? | 13 |
| VII. 2004–2010 | How did internet circulation intensify exchange without erasing Rio, Baltimore, Croydon, Luanda, or South Africa? | 14 |
| VIII. 2010–2015 | What was the narrower festival-EDM constellation, and what developed beside it? | 13 |
| IX. 2015–2022 | How do local scenes, global circulation, and revivals coexist? | 12 |

## High-value comparison links

- `house pulse`: Chicago jack ↔ deep house ↔ acid ↔ vocal/garage ↔ French touch ↔ microhouse ↔ South African house ↔ festival tech house
- `break science`: breakbeat hardcore ↔ jungle ↔ atmospheric/jump-up/techstep/liquid/neuro D&B ↔ new-jungle revival
- `rave to crossover`: 4hero / SL2 ↔ proposed Prodigy bridge ↔ Chemical Brothers / Fatboy Slim
- `industrial boundary`: Nitzer Ebb ↔ proposed Nine Inch Nails comparison ↔ electroclash / industrial-techno and post-club routes
- `jump-up afterlife`: Super Sharp Shooter ↔ Mr Happy ↔ Low Blow/foghorn ↔ Told You (Soundboy)
- `missing kick`: speed garage ↔ 2-step ↔ proto-dubstep ↔ dubstep ↔ post-dubstep
- `dubstep after brostep`: early dubstep ↔ brostep ↔ riddim/trench ↔ modern tearout ↔ renewed deep-140 visibility
- `hard continuum`: hardcore techno ↔ gabber/happy hardcore ↔ hardstyle ↔ Frenchcore
- `city-club function`: ballroom runway ↔ Baltimore break ↔ Jersey command ↔ Chicago footwork battle ↔ Detroit ghettotech mix logic ↔ New Orleans bounce response
- `global rhythmic systems`: funk carioca ↔ kuduro/batida ↔ gqom/amapiano ↔ singeli ↔ Egyptian shaabi-derived performance ↔ digital cumbia/budots
- `dembow meanings`: Jamaican dancehall riddim ↔ Panamanian reggae en español ↔ Puerto Rican reggaetón ↔ Dominican dembow and later neoperreo mutations
- `drummer's route`: Plastikman ↔ LTJ Bukem ↔ Roni Size ↔ RP Boo ↔ Venetian Snares ↔ Islam Chipsy & EEK ↔ DJ Lag ↔ Jlin

## Navigation principles

- Use this atlas to ask where to listen next, not to decide that a track has one true label.
- Treat unrepresented nodes as research prompts. Their presence here does not authorize a manifest or Spotify change.
- Treat artist bridge nodes differently from genre nodes: The Prodigy, Nine Inch Nails, and “Incredible” illuminate crossings rather than adding three new genre families.
- When a name changes meaning across time or place—garage, progressive house, dembow, riddim, or tearout—return to the prose guide for the qualified explanation.
- Obsidian remains a navigation layer. It is not the authority for dates, versions, Spotify availability, or final editorial decisions.
