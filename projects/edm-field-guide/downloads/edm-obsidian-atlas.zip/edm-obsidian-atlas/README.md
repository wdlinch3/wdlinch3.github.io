# EDM Genre Atlas for Obsidian

This is the optional nonlinear companion to *A Field Guide to Electronic Dance Music*.

1. Unzip this folder.
2. In Obsidian, choose **Open folder as vault** and select `edm-obsidian-atlas`.
3. Open `START HERE.md`.
4. For the circular dot-and-line view, open Graph View and use the documented path filter.
5. For the deliberately arranged network, open `EDM Genre Network.canvas`.

The public guide is https://wdlinch3.github.io/projects/edm-field-guide/ and the full-screen web map is https://wdlinch3.github.io/projects/edm-field-guide/web-map/.

The Quarto guide and track manifest remain authoritative for the listening curriculum. These Obsidian files are generated navigation aids.
